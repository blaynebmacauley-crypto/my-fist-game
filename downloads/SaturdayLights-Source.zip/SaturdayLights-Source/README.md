# Saturday Lights — Native PC edition

A playable native Godot 4.6.3 football prototype with original athlete, stadium and animation assets. It is separate from the browser version; Godot is not required to play an exported release.

Download the Windows ZIP, extract the entire archive, and run `SaturdayLights.exe`. Keep `SaturdayLights.pck` beside the executable. Linux x86-64 and editable source packages are also provided. The project uses the compatibility renderer and requires a computer with OpenGL 3.3 support; actual performance depends on hardware. Windows x86-64 releases are exported on Linux using official Godot templates. See `docs/VERIFICATION.md` for the exact checks performed.

WASD/left stick moves your athlete; Shift/right trigger sprints; Space/gamepad A snaps. QB uses 1/2/3 or X/Y/B to pass; WR uses 1/X to call for the ball. Q/E jukes; LB uses Q for a lateral cut and E/X to tackle. C/left bumper changes camera. Esc/Start pauses. Mouse or focused buttons work in menus.

Quick Play supports QB, RB, WR and LB. Career starts unranked with Season Opener, Rivalry Game and State Championship. Your recorded production determines recruiting stars and offers. Commit to an available school to play four condensed three-game college seasons. Coach practice and XP upgrades are available between games. Saves are local to the native application; existing browser saves remain in browser storage.

This is a simplified football game with 11-on-11 movement, blocking, routes, passing, catching, running, tackling, scoring and off-screen possession simulation. It is not a licensed EA game, a verified 2026 roster database, or a complete NCAA rules/scheduling simulation. College names identify programs; athletes, coaches, uniforms, offers and roster needs are fictional. No official logos or real-player likenesses are included.

Open `project.godot` in Godot 4.6.3 to edit the source. The original athlete GLB generator is `tools/build_athlete.py` and requires Blender 4.3+. Export templates can be fetched from official Godot releases with `tools/fetch_export_templates.py`; `tools/package.py` makes portable ZIPs, source and SHA-256 manifests. Engine and third-party notices are in `docs/`.
