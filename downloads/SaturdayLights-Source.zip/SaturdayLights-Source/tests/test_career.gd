extends SceneTree

const Career = preload("res://scripts/career.gd")
var checks: int = 0


func _init() -> void:
	call_deferred("run_tests")


func check(condition: bool, message: String) -> void:
	if not condition:
		push_error("FAIL: " + message)
		quit(1)
		assert(condition, message)
	checks += 1


func result(yards: int = 120, td: int = 1, won: bool = true) -> Dictionary:
	return {"yards": yards, "td": td, "completions": 4, "tackles": 0, "home": 21 if won else 7, "away": 14}


func run_tests() -> void:
	for role in Career.POSITIONS:
		for archetype in Career.ARCHETYPES[role]:
			var player: Dictionary = Career.new_player("Avery Stone", role, str(archetype["id"]))
			check(player["position"] == role and player["archetype"] == archetype["id"], "position/archetype retained")
			check(player["ratings"] == Career.ratings(player), "cached ratings follow effective attributes")
			check(player["games"] == 0 and player["stars"] == 0 and player["offers"].is_empty(), "unranked, no offers before high school")
	check(Career.new_player("\n\t", "invalid")["name"] == "Jordan Hayes", "invalid identity uses defaults")
	var qb: Dictionary = Career.new_player("Jordan", "QB", "dual-threat")
	check(Career.ratings(qb)["speed"] == 72, "archetype affects actual speed")
	check(Career.practice(qb), "first film session is allowed")
	check(qb["xp"] == 20 and qb["trust"] == 50, "film session earns XP and trust")
	check(not Career.practice(qb) and qb["xp"] == 20, "film session cannot be repeated in same week")
	check(not Career.buy_upgrade(qb, "speed"), "upgrades require a completed game")
	Career.complete_game(qb, result())
	check(qb["games"] == 1 and qb["log"].size() == 1, "game completes exactly once per explicit completion")
	check(qb["xp"] == 190 and qb["xp_earned"] == 190, "production earns real XP")
	check(Career.buy_upgrade(qb, "speed"), "available XP can buy movement upgrade")
	check(qb["xp"] == 130 and qb["xp_spent"] == 60 and Career.ratings(qb)["speed"] == 76, "upgrade deducts XP and changes attributes")
	check(not Career.buy_upgrade(qb, "catching"), "role-specific upgrades reject foreign attributes")
	check(Career.buy_upgrade(qb, "speed") and qb["xp"] == 30, "second level has rising cost")
	check(not Career.buy_upgrade(qb, "speed") and qb["upgrades"]["speed"] == 2, "insufficient XP cannot grant a level")
	check(Career.practice(qb), "next game week restores one practice")
	Career.complete_game(qb, result())
	Career.complete_game(qb, result())
	check(qb["games"] == 3 and qb["year"] == 1, "exactly three high-school games unlock signing")
	check(not Career.can_play(qb), "college games wait for commitment")
	var at_signing: Dictionary = qb.duplicate(true)
	Career.complete_game(qb, result())
	check(qb == at_signing, "blocked college game cannot change statistics or XP")
	check(qb["stars"] >= 1 and qb["stars"] <= 5 and qb["offers"].has("Auburn"), "performance grants bounded rating and at least a safety offer")
	check(not Career.commit(qb, "Imaginary University"), "unknown school cannot be committed")
	var chosen: String = str(qb["offers"][0])
	check(Career.commit(qb, chosen) and Career.can_play(qb), "eligible commitment unlocks college")
	check(not Career.commit(qb, "Auburn"), "commitment cannot silently change later")
	var frozen_stars: int = qb["stars"]
	for i in 12:
		Career.complete_game(qb, result(300, 4))
	check(qb["games"] == 15 and qb["year"] == 4 and qb["complete"], "four three-game college seasons complete career")
	check(qb["stars"] == frozen_stars, "college production cannot rewrite recruiting rating")
	check(not Career.can_play(qb) and not Career.practice(qb) and not Career.buy_upgrade(qb, "speed"), "completed careers cannot accrue new progress")
	var ended: Dictionary = qb.duplicate(true)
	Career.complete_game(qb, result())
	check(qb == ended, "sixteenth game is rejected without mutation")
	var weak: Dictionary = Career.new_player("Low Production", "LB")
	var strong: Dictionary = Career.new_player("High Production", "LB")
	for i in 3:
		Career.complete_game(weak, {"yards": 0, "td": 0, "completions": 0, "tackles": 0, "home": 0, "away": 7})
		Career.complete_game(strong, {"yards": 0, "td": 0, "completions": 0, "tackles": 8, "home": 21, "away": 7, "difficulty": 1.25})
	check(weak["stars"] == 1 and strong["stars"] == 5, "tackle production, difficulty and wins determine recruiting quality")
	check(strong["national_rank"] <= 120 and weak["national_rank"] > 3000, "fictional recruiting rankings agree with star tiers")
	check(Career.offers(strong).size() > Career.offers(weak).size(), "better production earns more scholarships")
	check(not Career.commit(weak, "Georgia"), "unearned offers stay unavailable")
	check(Career.commit(strong, "Auburn"), "valid strong recruit fixture enters college")
	var invalid_result: Dictionary = strong.duplicate(true)
	Career.complete_game(strong, {"yards": NAN, "td": 0})
	check(strong == invalid_result, "invalid statistics cannot corrupt progress")
	var tampered: Dictionary = Career.new_player("Bad Upgrade", "WR")
	tampered["upgrades"]["speed"] = 3
	check(not Career.save(tampered), "unpaid upgrade saves are rejected")
	var old_text: String = ""
	var had_save: bool = FileAccess.file_exists(Career.SAVE_FILE)
	if had_save:
		old_text = FileAccess.get_file_as_string(Career.SAVE_FILE)
	check(Career.save(qb), "valid completed career saves")
	var loaded: Dictionary = Career.load_save()
	check(not loaded.is_empty() and loaded["games"] == 15 and loaded["school"] == chosen, "save/load retains progress and commitment")
	check(loaded["xp"] == qb["xp"] and loaded["upgrades"] == qb["upgrades"] and Career.ratings(loaded) == Career.ratings(qb), "save/load retains spent XP and effective upgrades")
	DirAccess.rename_absolute(Career.SAVE_FILE, Career.SAVE_FILE + ".bak")
	check(Career.load_save()["games"] == 15, "interrupted atomic replacement recovers last valid backup")
	DirAccess.rename_absolute(Career.SAVE_FILE + ".bak", Career.SAVE_FILE)
	var file: FileAccess = FileAccess.open(Career.SAVE_FILE, FileAccess.WRITE)
	file.store_string("{broken json")
	file.close()
	check(Career.load_save().is_empty(), "malformed saves fail safely")
	if had_save:
		file = FileAccess.open(Career.SAVE_FILE, FileAccess.WRITE)
		file.store_string(old_text)
		file.close()
	else:
		DirAccess.remove_absolute(Career.SAVE_FILE)
	print("PASS: %d native career checks" % checks)
	quit(0)
