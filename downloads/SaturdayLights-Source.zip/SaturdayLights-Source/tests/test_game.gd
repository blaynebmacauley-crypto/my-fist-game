extends SceneTree
## Integration checks run the native Main scene, imported athlete and production game rules.
const MainScene = preload("res://Main.tscn")
const Career = preload("res://scripts/career.gd")
var game
var checks: int = 0

func _init() -> void:
	call_deferred("run_tests")

func check(condition: bool, message: String) -> void:
	if not condition:
		push_error("FAIL: " + message)
		quit(1)
		assert(condition, message)
	checks += 1

func park_defenders() -> void:
	for index in range(11,22):
		game.actors[index].global_position = Vector3(40.0 + (index-11)*1.0,0.03,85.0)
		game.actors[index].velocity = Vector3.ZERO
		game.actors[index].speed = 0.0

func new_play(role: String = "QB") -> void:
	game.set_physics_process(false)
	game.start_quick_play(role)
	game.snap()
	park_defenders()

func tick(count: int = 1, delta: float = 0.04) -> void:
	for index in range(count):
		game._physics_process(delta)

func press_key(code: Key) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	event.keycode = code
	event.pressed = true
	game._unhandled_input(event)

func positions() -> Array[Vector3]:
	var result: Array[Vector3] = []
	for actor in game.actors:
		result.append(actor.global_position)
	return result

func run_tests() -> void:
	game = MainScene.instantiate()
	root.add_child(game)
	await process_frame
	await physics_frame
	game.set_physics_process(false)
	check(game.ready_complete, "native scene reaches ready")
	check(game.actors.size() == 22, "real native formation has eleven athletes per side")
	for actor in game.actors:
		var visual: Dictionary = actor.get_visual_stats()
		check(visual.loaded and visual.meshes > 0, "athlete loads the imported human model")
		for action in ["idle", "run", "carry", "catch", "throw", "tackle"]:
			var found := false
			for clip in visual.animations:
				if str(clip).to_lower().ends_with(action): found = true
			check(found, "athlete has authored " + action + " animation")
		check(actor.collision_layer == 1 and actor.collision_mask == 3, "athlete uses actual player/world collisions")
		check(visual.hand_anchor, "football can attach to the animated hand")
	print("PASS native scene: 22 imported athletes, six animation clips, real hand anchors and capsule collisions")

	new_play()
	check(game.snapshot().can_pass, "QB can pass behind scrimmage")
	check(game.throw_ball(0), "legal QB pass launches")
	check(game.carrier == -1 and not game.flight.is_empty(), "pass creates a live ball flight")
	check(game.stats.attempts == 1, "legal pass counts one attempt")
	new_play()
	game.actors[0].global_position.z = game.spot + 0.1
	tick(1,0.001)
	check(game.crossed_scrimmage, "crossing scrimmage is remembered")
	for target in range(3):
		check(not game.throw_ball(target), "each forward pass target is locked beyond scrimmage")
	check(game.stats.attempts == 0 and game.flight.is_empty(), "illegal pass does not launch or change statistics")
	game.actors[0].global_position.z = game.spot - 2.0
	check(not game.throw_ball(0), "retreating does not restore a pass on the same down")
	game.formation()
	game.snap()
	check(game.throw_ball(1), "next down restores legal passes")
	print("PASS native passing: behind-line passes work; crossing and retreat lock all targets until next down")

	new_play()
	game.spot = 2.0
	game.line_to_gain = 12.0
	game.formation()
	game.snap()
	park_defenders()
	tick(3,0.001)
	check(game.actors[0].global_position.z < 0 and game.phase == "live", "runner can remain live in the own end zone")
	check(game.away_score == 0, "crossing own goal line alone is not a safety")
	game.actors[11].global_position = game.actors[0].global_position + Vector3(0,0,0.5)
	check(game.begin_tackle(11,true), "matched ball-carrier contact begins a tackle")
	tick(10)
	check(game.phase == "tackle" and game.away_score == 0, "wrap animation does not score a safety before grounding")
	tick(24)
	check(game.phase == "dead" and game.away_score == 2, "grounded carrier in own end zone concedes two points")
	check(game.actors[0].get_visual_stats().downed, "carrier holds the final downed pose")
	new_play()
	game.actors[0].global_position.z = -10.1
	tick(1,0.001)
	check(game.phase == "dead" and game.away_score == 2, "own back line is a legal boundary safety")
	new_play()
	game.actors[0].global_position.z = 100.1
	tick(1,0.001)
	check(game.phase == "dead" and game.home_score == 7, "opposing goal plane scores touchdown and automatic extra point")
	var frozen := positions()
	Input.action_press("forward")
	tick(10)
	Input.action_release("forward")
	check(positions() == frozen, "dead ball freezes every actor despite held movement input")
	print("PASS native scoring: own end zone stays live, grounded safety and boundary safety score, touchdown freezes play")

	new_play("WR")
	game.play_time = 1.0
	game._request_pass(0)
	check(game.carrier == -1 and not game.flight.is_empty(), "WR calls the QB for a real pass")
	var end: Vector3 = game.flight.end
	game.actors[6].global_position = Vector3(end.x,0.03,end.z)
	game._flight_step(float(game.flight.duration))
	check(game.carrier == 6 and game.stats.completions == 1 and game.stats.catches == 1, "aligned WR actually catches the ball")
	new_play("WR")
	game.play_time = 1.0
	game._request_pass(0)
	end = game.flight.end
	game.actors[6].global_position = Vector3(end.x+1.25,0.03,end.z)
	game._flight_step(float(game.flight.duration))
	check(game.phase == "dead" and game.stats.completions == 0, "WR cannot vacuum a ball from 1.25 yards away")
	new_play("RB")
	tick(1,0.7)
	check(game.carrier == 10, "RB receives an actual handoff")
	new_play("LB")
	check(game.controlled_index() == 16 and game.is_run, "LB controls the home defense against a run")
	tick(1,0.7)
	check(game.carrier == 10, "opponent run develops with a handoff in LB mode")
	game.formation()
	game.snap()
	park_defenders()
	check(not game.is_run, "LB opponent switches to a passing concept")
	game.play_time = 2.7
	game._pocket_qb(0.001)
	check(not game.flight.is_empty(), "LB opponent passing play actually throws")
	print("PASS native positions: WR call/catch/miss, RB handoff, LB opponent run/pass development")

	new_play()
	var stamina_before: float = game.stamina
	press_key(KEY_Q)
	check(not game.skill.is_empty() and int(game.skill.side) == -1, "Q starts a native camera-left skill cut")
	check(is_equal_approx(game.stamina,stamina_before-0.18), "skill spends eighteen percent stamina")
	var spent_stamina: float = game.stamina
	press_key(KEY_E)
	check(int(game.skill.side) == -1 and is_equal_approx(game.stamina,spent_stamina), "cooldown prevents spam and double charges")
	var initial: Vector3 = game.actors[0].global_position
	var right: Vector3 = game.camera.global_basis.x
	game.set_physics_process(true)
	for frame in range(12): await physics_frame
	game.set_physics_process(false)
	check((game.actors[0].global_position-initial).dot(right) < -0.3, "skill moves the actual CharacterBody in native physics")
	game._set_paused(true)
	var paused_skill: Dictionary = game.skill.duplicate(true)
	var paused_stamina: float = game.stamina
	var paused_positions := positions()
	press_key(KEY_E)
	tick(8)
	check(game.skill == paused_skill and is_equal_approx(game.stamina,paused_stamina), "pause freezes skill timing and stamina")
	check(positions() == paused_positions, "pause freezes native physics actors")
	game._set_paused(false)
	tick(60)
	check(game.skill.is_empty() and game.skill_cooldown == 0.0, "skill recovers after its movement and cooldown")
	press_key(KEY_E)
	check(not game.skill.is_empty() and int(game.skill.side) == 1, "E permits a camera-right cut after recovery")
	new_play("LB")
	press_key(KEY_Q)
	check(not game.skill.is_empty(), "LB keeps Q as a lateral cut")
	game.actors[16].global_position = game.actors[0].global_position + Vector3(0,0,0.5)
	game.actors[0].velocity = Vector3.ZERO
	press_key(KEY_E)
	check(game.phase == "tackle" and game.tackle.defender == 16, "LB E remains the tackle action")
	print("PASS native skills: real physics movement, stamina, spam guard, pause, recovery and LB control mapping")

	game._new_career("QA Recruit", "QB", "dual-threat")
	check(game.mode == "career" and game.career.games == 0, "created career starts before the first game")
	for hs in range(3):
		game._play_career()
		check(game.mode == "play" and game.home_team == "STATE HIGH", "created athlete stays with the same high-school team")
		game.stats = {"yards":360.0,"td":4,"completions":10,"attempts":12,"tackles":0,"catches":0,"big_plays":3}
		game.home_score=28
		game.away_score=14
		game._end_game()
		check(game.career.games == hs+1, "completed native match advances career exactly once")
		game._menu()
	check(game.career.games == 3 and not game.career.offers.is_empty(), "exactly three HS games unlock actual recruiting offers")
	game._play_career()
	check(game.mode == "career", "signing-day gate blocks college until commitment")
	game._commit_school(str(game.career.offers[0]))
	check(not str(game.career.school).is_empty() and Career.can_play(game.career), "native commitment unlocks college")
	for college in range(12):
		game._play_career()
		check(game.mode == "play" and game.home_team == game.career.school, "college games use the chosen school")
		game.stats = {"yards":210.0,"td":2,"completions":7,"attempts":11,"tackles":0,"catches":0,"big_plays":1}
		game.home_score=21
		game.away_score=17
		game._end_game()
		game._menu()
	check(game.career.games == 15 and game.career.complete and not Career.can_play(game.career), "four three-game college seasons finish the native career")
	var saved: Dictionary = Career.load_save()
	check(saved.games == 15 and saved.school == game.career.school, "native completed career survives save/load")
	print("PASS native career integration: three HS games, recruiting gate, commitment, four condensed college seasons and persisted completion")
	game.queue_free()
	await process_frame
	print("PASS native game integration: %d checks" % checks)
	quit(0)
