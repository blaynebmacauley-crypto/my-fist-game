#!/usr/bin/env python3
"""Export portable desktop games and a clean Godot source archive.

Example: python3 native/tools/package.py --platform all --data-home /workspace/native-tools
The export is cross-compiled by official Godot templates. Exporting Windows on
Linux does not establish that the Windows runtime was tested on Windows.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

from fetch_export_templates import fetch, TEMPLATE_VERSION

PROJECT = Path(__file__).resolve().parents[1]
IGNORED = {".godot", ".git", ".build-tools", ".export_templates", "builds", "downloads", "__pycache__"}
README = """SATURDAY LIGHTS — NATIVE FOOTBALL PROTOTYPE

PLAY
Extract this whole ZIP into a folder first, then launch {executable}.
Keep the game executable and SaturdayLights.pck together.
This build does not require Godot or a browser to be installed.

CONTROLS
WASD / left stick: move the created athlete
Shift / gamepad right trigger: sprint
Space / gamepad A: snap
1, 2, 3: choose a pass target (QB)
1: call for the ball (WR)
Q/E: cut or juke; LB uses E for tackling
Esc: pause
Mouse: menus and on-screen controls

The game includes simplified 11-on-11 football and a condensed career.
Players, coaches and uniforms are fictional. College names identify programs;
there are no licensed player rosters, likenesses or official team logos.
The artwork and animations are original prototype assets, not scanned players.

Your native career is saved locally by Godot in its user data folder.
Browser saves remain in your browser and are not automatically imported.

BUILD / TEST STATUS
Engine: Godot 4.6.3 stable, compatibility renderer.
The Windows x86-64 release is exported on Linux using official Godot templates.
See the accompanying download page or project verification notes for tests run.
No Windows code-signing certificate is included.

LICENSES
Godot Engine is MIT-licensed. Full engine and third-party notices are included
in the licenses folder. See asset-notes.md for original asset provenance.
"""


def archive_files(path: Path, files: list[tuple[Path, str]], executable: set[str] = frozenset()) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=8) as archive:
        for source, name in sorted(files, key=lambda entry: entry[1]):
            info = zipfile.ZipInfo(name, (2026, 10, 29, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = ((0o100755 if name in executable else 0o100644) << 16)
            archive.writestr(info, source.read_bytes())


def common_files(staging: Path, executable: str) -> list[tuple[Path, str]]:
    readme = staging / "README.txt"
    readme.write_text(README.format(executable=executable))
    files = [(readme, "README.txt")]
    for name in ("GODOT-LICENSE.txt", "GODOT-COPYRIGHT.txt"):
        source = PROJECT / "docs" / name
        if not source.is_file():
            raise FileNotFoundError(f"Required engine license notice missing: {source}")
        files.append((source, "licenses/" + name))
    notes = PROJECT / "assets" / "asset-notes.md"
    if notes.is_file():
        files.append((notes, "asset-notes.md"))
    verification = PROJECT / "docs" / "VERIFICATION.md"
    if verification.is_file():
        files.append((verification, "VERIFICATION.md"))
    return files


def checked_godot(command: list[str], environment: dict, log_path: Path) -> None:
    result = subprocess.run(command, env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log_path.write_text(result.stdout)
    # Godot can return zero after script import failures. Never turn that into a
    # supposedly successful playable release just because the executable exists.
    if result.returncode or re.search(r"(?:SCRIPT ERROR:|Parse Error:|ERROR:)", result.stdout):
        print(result.stdout[-6000:], flush=True)
        raise RuntimeError(f"Godot build check failed; complete log: {log_path}")
    print(f"Godot check passed: {log_path.name}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--platform", choices=("windows", "linux", "source", "all"), default="all")
    parser.add_argument("--godot", default=shutil.which("godot") or "godot")
    parser.add_argument("--data-home", type=Path, default=PROJECT.parent / ".build-tools")
    parser.add_argument("--output", type=Path, default=PROJECT.parent / "downloads")
    parser.add_argument("--skip-import", action="store_true")
    args = parser.parse_args()
    data_home, output = args.data_home.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    manifest = {"engine": "Godot 4.6.3 stable", "template_version": TEMPLATE_VERSION, "artifacts": {}}
    if args.platform != "source":
        templates = fetch(data_home)
        environment = os.environ.copy()
        environment["XDG_DATA_HOME"] = str(data_home)
        environment["XDG_CACHE_HOME"] = str(data_home / "cache")
        environment["XDG_CONFIG_HOME"] = str(data_home / "config")
        if not args.skip_import:
            checked_godot([args.godot, "--headless", "--path", str(PROJECT), "--editor", "--import", "--quit"], environment, output / "build-import.log")
        for platform in ("windows", "linux"):
            if args.platform not in (platform, "all"):
                continue
            staging = output / (".staging-" + platform)
            staging.mkdir(parents=True, exist_ok=True)
            executable = "SaturdayLights.exe" if platform == "windows" else "SaturdayLights.x86_64"
            binary = staging / executable
            preset = "Windows" if platform == "windows" else "Linux"
            checked_godot([args.godot, "--headless", "--path", str(PROJECT), "--export-release", preset, str(binary)], environment, output / ("build-" + platform + ".log"))
            pack = staging / "SaturdayLights.pck"
            if not binary.is_file() or not pack.is_file():
                raise RuntimeError(f"{preset} export did not produce both executable and PCK")
            prefix = "SaturdayLights-" + preset + "/"
            files = common_files(staging, executable) + [(binary, executable), (pack, pack.name)]
            destination = output / ("SaturdayLights-" + preset + ".zip")
            archive_files(destination, [(path, prefix + name) for path, name in files], {prefix + executable})
            manifest["artifacts"][destination.name] = {"bytes": destination.stat().st_size, "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(), "platform": preset, "export": "release", "runtime_tested_by_packager": False}
            print(f"Packaged {destination} ({destination.stat().st_size / 1048576:.1f} MiB)", flush=True)
        manifest["template_provenance"] = json.loads((templates / "template-provenance.json").read_text())
    if args.platform in ("all", "source"):
        files = []
        for source in PROJECT.rglob("*"):
            relative = source.relative_to(PROJECT)
            if not source.is_file() or any(part in IGNORED for part in relative.parts) or source.suffix in (".pyc", ".log", ".blend1"):
                continue
            files.append((source, "SaturdayLights-Source/" + relative.as_posix()))
        destination = output / "SaturdayLights-Source.zip"
        archive_files(destination, files)
        manifest["artifacts"][destination.name] = {"bytes": destination.stat().st_size, "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(), "platform": "Godot project source"}
        print(f"Packaged {destination} ({destination.stat().st_size / 1048576:.1f} MiB)", flush=True)
    manifest_path = output / "build-manifest.json"
    if manifest_path.is_file():
        previous = json.loads(manifest_path.read_text())
        previous["artifacts"] = {**previous.get("artifacts", {}), **manifest["artifacts"]}
        previous.update({key: value for key, value in manifest.items() if key != "artifacts"})
        manifest = previous
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    checksum_lines = [entry["sha256"] + "  " + name for name, entry in sorted(manifest["artifacts"].items())]
    (output / "SHA256SUMS.txt").write_text("\n".join(checksum_lines) + "\n")


if __name__ == "__main__":
    main()
