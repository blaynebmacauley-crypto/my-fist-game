#!/usr/bin/env python3
"""Run a native graphics check on an isolated software-rendered X display.

This is a developer utility for Linux cloud testing, not a game dependency.
Uses an existing Xorg dummy driver or Xvfb; it does not install system packages.
Pass Godot without --headless so its actual OpenGL renderer produces the image.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time


def display_ready(display: str, environment: dict) -> bool:
    if shutil.which("xdpyinfo"):
        return subprocess.run(["xdpyinfo", "-display", display], env=environment, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    number = display.split(":")[-1].split(".")[0]
    return Path("/tmp/.X11-unix/X" + number).exists()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--display", default=":93")
    parser.add_argument("--size", default="1440x900")
    parser.add_argument("--data-home", type=Path, default=Path(__file__).resolve().parents[2] / ".build-tools")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("Provide a command after --")
    width, height = map(int, args.size.split("x"))
    pixel_clock = (width + 464) * (height + 34) * 60 / 1_000_000
    data_home = args.data_home.resolve()
    data_home.mkdir(parents=True, exist_ok=True)
    environment = os.environ.copy()
    environment.update(DISPLAY=args.display, LIBGL_ALWAYS_SOFTWARE="1", XDG_DATA_HOME=str(data_home), XDG_CACHE_HOME=str(data_home / "cache"), XDG_CONFIG_HOME=str(data_home / "config"))
    server = None
    log = None
    with tempfile.TemporaryDirectory(prefix="saturday-display-", dir=data_home) as temporary:
        temporary_path = Path(temporary)
        try:
            if not display_ready(args.display, environment):
                xorg = Path("/usr/lib/xorg/Xorg")
                xvfb = shutil.which("Xvfb")
                log = open(temporary_path / "server-output.log", "w")
                if xorg.is_file() and Path("/usr/lib/xorg/modules/drivers/dummy_drv.so").is_file():
                    config = temporary_path / "dummy.conf"
                    config.write_text(f'''Section "ServerFlags"
    Option "AutoAddDevices" "false"
    Option "AutoEnableDevices" "false"
    Option "DontVTSwitch" "true"
    Option "AllowMouseOpenFail" "true"
EndSection
Section "Device"
    Identifier "DummyDevice"
    Driver "dummy"
    VideoRam 256000
EndSection
Section "Monitor"
    Identifier "DummyMonitor"
    HorizSync 5.0-1000.0
    VertRefresh 5.0-200.0
    Modeline "{width}x{height}" {pixel_clock:.3f} {width} {width + 80} {width + 232} {width + 464} {height} {height + 3} {height + 9} {height + 34}
EndSection
Section "Screen"
    Identifier "DummyScreen"
    Device "DummyDevice"
    Monitor "DummyMonitor"
    DefaultDepth 24
    SubSection "Display"
        Depth 24
        Virtual {width} {height}
        Modes "{width}x{height}"
    EndSubSection
EndSection
Section "ServerLayout"
    Identifier "DummyLayout"
    Screen "DummyScreen"
EndSection
''')
                    launch = [str(xorg), args.display, "-noreset", "-nolisten", "tcp", "-config", str(config), "-logfile", str(temporary_path / "Xorg.log")]
                elif xvfb:
                    launch = [xvfb, args.display, "-screen", "0", args.size + "x24", "-nolisten", "tcp"]
                else:
                    raise SystemExit("Native graphics check needs an existing X display, Xorg with dummy driver, or Xvfb.")
                server = subprocess.Popen(launch, env=environment, stdout=log, stderr=subprocess.STDOUT)
                for _ in range(100):
                    if display_ready(args.display, environment):
                        break
                    if server.poll() is not None:
                        raise RuntimeError("Test display could not start: " + (temporary_path / "server-output.log").read_text())
                    time.sleep(.05)
                else:
                    raise RuntimeError("Test display did not become ready")
            result = subprocess.run(command, env=environment)
            raise SystemExit(result.returncode)
        finally:
            if server is not None:
                server.terminate()
                try:
                    server.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    server.kill()
            if log is not None:
                log.close()


if __name__ == "__main__":
    main()
