#!/usr/bin/env python3
"""Fetch official Godot release templates without downloading unrelated platforms.

Reads the ZIP central directory through authenticated HTTPS byte ranges, then
downloads only the two desktop release members. zipfile validates their CRCs.
The exact extracted binaries' SHA-256 hashes are recorded for build provenance.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import urllib.request
import zipfile

VERSION = "4.6.3"
RELEASE = VERSION + "-stable"
TEMPLATE_VERSION = VERSION + ".stable"
ARCHIVE = f"https://github.com/godotengine/godot-builds/releases/download/{RELEASE}/Godot_v{RELEASE}_export_templates.tpz"
MEMBERS = ("templates/windows_release_x86_64.exe", "templates/linux_release.x86_64")


class HTTPSRangeReader(io.RawIOBase):
    def __init__(self, url: str):
        response = urllib.request.urlopen(urllib.request.Request(url, method="HEAD"), timeout=60)
        self.url = response.geturl()
        self.length = int(response.headers["Content-Length"])
        self.position = 0
        self.cache: list[tuple[int, bytes]] = []

    def seekable(self):
        return True

    def readable(self):
        return True

    def tell(self):
        return self.position

    def seek(self, offset, whence=0):
        self.position = offset if whence == 0 else self.position + offset if whence == 1 else self.length + offset
        return self.position

    def read(self, size=-1):
        if size < 0:
            size = self.length - self.position
        size = min(size, self.length - self.position)
        if size <= 0:
            return b""
        start = self.position
        for base, data in self.cache:
            if base <= start and start + size <= base + len(data):
                self.position += size
                return data[start - base:start - base + size]
        # Cache a short forward window for ZIP headers and central-directory reads.
        count = min(max(size, 65536), self.length - start)
        request = urllib.request.Request(self.url, headers={"Range": f"bytes={start}-{start + count - 1}"})
        with urllib.request.urlopen(request, timeout=120) as response:
            if response.status != 206:
                raise RuntimeError("Release server did not honor byte ranges; refusing a full-archive download")
            data = response.read(count + 1)
        if len(data) != count:
            raise RuntimeError("Truncated release archive range")
        if count <= 131072:
            self.cache.append((start, data))
        self.position += size
        return data[:size]


def fetch(data_home: Path) -> Path:
    destination = data_home / "godot" / "export_templates" / TEMPLATE_VERSION
    destination.mkdir(parents=True, exist_ok=True)
    manifest_path = destination / "template-provenance.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        if all((destination / Path(member).name).is_file() and hashlib.sha256((destination / Path(member).name).read_bytes()).hexdigest() == manifest.get("files", {}).get(Path(member).name, {}).get("sha256") for member in MEMBERS):
            print(f"Verified cached templates: {destination}", flush=True)
            return destination
    print("Reading official Godot desktop template archive directory…", flush=True)
    remote = HTTPSRangeReader(ARCHIVE)
    provenance = {"godot_version": RELEASE, "archive_url": ARCHIVE, "archive_bytes": remote.length, "verification": "Official HTTPS release URL and ZIP member CRC; SHA-256 recorded per extracted member. Whole-archive digest not verified because unrelated platform data was not downloaded.", "files": {}}
    with zipfile.ZipFile(remote) as archive:
        for member in MEMBERS:
            info = archive.getinfo(member)
            name = Path(member).name
            print(f"Downloading {name}: {info.compress_size / 1048576:.1f} MiB compressed…", flush=True)
            data = archive.read(member)
            (destination / name).write_bytes(data)
            (destination / name).chmod(0o755)
            provenance["files"][name] = {"bytes": len(data), "zip_crc32": f"{info.CRC:08x}", "sha256": hashlib.sha256(data).hexdigest()}
    manifest_path.write_text(json.dumps(provenance, indent=2) + "\n")
    print(f"Desktop templates ready: {destination}", flush=True)
    return destination


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-home", type=Path, default=Path(__file__).resolve().parents[2] / ".build-tools")
    args = parser.parse_args()
    fetch(args.data_home.resolve())
