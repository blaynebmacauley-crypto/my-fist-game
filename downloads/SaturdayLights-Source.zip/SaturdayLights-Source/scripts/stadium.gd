class_name FootballStadium
extends Node3D

## Original stadium artwork. Coordinates are yards, with the offense moving +Z.
## The scene is visual only; football boundaries and collisions belong to game.gd.
var _built: bool = false
var _score_labels: Array[Label3D] = []
var _materials: Dictionary = {}
var _rng: RandomNumberGenerator = RandomNumberGenerator.new()
var _score_key: String = ""
var _home_name: String = "STATE"
var _away_name: String = "VALLEY"
var _endzone_labels: Array[Label3D] = []
var _last_score: Vector3i = Vector3i(0, 0, 180)


func _ready() -> void:
	build()


func build() -> void:
	if _built:
		return
	_built = true
	_rng.seed = 882711
	name = "SaturdayLightsStadium"
	_build_lighting()
	_build_field()
	_build_bowl()
	_build_crowd()
	_build_roofs_and_press()
	_build_scoreboards()
	_build_sidelines()
	_score_key = ""
	update_score(_last_score.x, _last_score.y, _last_score.z)
	set_meta("stadium_art", {"original": true, "crowd": get_meta("spectator_count", 0), "field_yards": 100})


func _material(color: Color, roughness: float = 0.85, metallic: float = 0.0) -> StandardMaterial3D:
	var key: String = color.to_html() + str(roughness) + str(metallic)
	if _materials.has(key):
		return _materials[key]
	var result: StandardMaterial3D = StandardMaterial3D.new()
	result.albedo_color = color
	result.roughness = roughness
	result.metallic = metallic
	_materials[key] = result
	return result


func _box(at: Vector3, size: Vector3, material: Material, casts: bool = true) -> MeshInstance3D:
	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = size
	var instance: MeshInstance3D = MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	if not casts:
		instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)
	return instance


func _cylinder(at: Vector3, radius: float, height: float, material: Material, casts: bool = true) -> MeshInstance3D:
	var mesh: CylinderMesh = CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 12
	var instance: MeshInstance3D = MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	if not casts:
		instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)
	return instance


func _label(text: String, at: Vector3, pixel_size: float, color: Color = Color.WHITE) -> Label3D:
	var label: Label3D = Label3D.new()
	label.text = text
	label.font_size = 96
	label.pixel_size = pixel_size
	label.modulate = color
	label.outline_size = 0
	label.shaded = true
	label.double_sided = false
	label.no_depth_test = false
	label.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	label.position = at
	add_child(label)
	return label


func _ground_text(text: String, x: float, z: float, pixel_size: float, reversed: bool = false, color: Color = Color("f0efdf")) -> Label3D:
	var label: Label3D = _label(text, Vector3(x, 0.034, z), pixel_size, color)
	label.rotation = Vector3(-PI / 2.0, PI if reversed else 0.0, 0.0)
	return label


func _build_lighting() -> void:
	var world: WorldEnvironment = WorldEnvironment.new()
	world.name = "DaylightEnvironment"
	var environment: Environment = Environment.new()
	var sky: Sky = Sky.new()
	var atmosphere: ProceduralSkyMaterial = ProceduralSkyMaterial.new()
	atmosphere.sky_top_color = Color("5d92b7")
	atmosphere.sky_horizon_color = Color("c8d8df")
	atmosphere.ground_bottom_color = Color("384737")
	atmosphere.ground_horizon_color = Color("b5c6cf")
	atmosphere.sky_curve = 0.18
	atmosphere.sky_energy_multiplier = 0.65
	atmosphere.sun_angle_max = 12.0
	atmosphere.sun_curve = 0.08
	sky.sky_material = atmosphere
	environment.background_mode = Environment.BG_SKY
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	environment.ambient_light_color = Color("cfdeea")
	environment.ambient_light_energy = 0.3
	environment.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	environment.tonemap_mode = Environment.TONE_MAPPER_ACES
	environment.tonemap_exposure = 0.78
	environment.fog_enabled = true
	environment.fog_light_color = Color("beced5")
	environment.fog_density = 0.0006
	environment.fog_sun_scatter = 0.12
	world.environment = environment
	add_child(world)
	var sun: DirectionalLight3D = DirectionalLight3D.new()
	sun.name = "StadiumSun"
	sun.rotation_degrees = Vector3(-44.0, -30.0, 0.0)
	sun.light_color = Color("fff1d8")
	sun.light_energy = 0.95
	sun.shadow_enabled = true
	sun.shadow_bias = 0.04
	sun.shadow_normal_bias = 1.2
	sun.directional_shadow_max_distance = 175.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.directional_shadow_blend_splits = true
	add_child(sun)


func _grass_material() -> StandardMaterial3D:
	var image: Image = Image.create(512, 1024, false, Image.FORMAT_RGB8)
	var noise: FastNoiseLite = FastNoiseLite.new()
	noise.seed = 62519
	noise.frequency = 0.075
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	for y in range(1024):
		var world_z: float = -10.0 + float(y) / 1024.0 * 120.0
		var stripe: float = 0.95 if int(floor(maxf(0.0, world_z) / 5.0)) % 2 == 0 else 1.05
		for x in range(512):
			var detail: float = noise.get_noise_2d(float(x), float(y)) * 0.018 + _rng.randf_range(-0.006, 0.006)
			image.set_pixel(x, y, Color((0.205 + detail * 0.65) * stripe, (0.31 + detail) * stripe, (0.145 + detail * 0.45) * stripe))
	image.generate_mipmaps()
	var texture: ImageTexture = ImageTexture.create_from_image(image)
	var material: StandardMaterial3D = StandardMaterial3D.new()
	material.albedo_texture = texture
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	material.roughness = 0.94
	var bump: NoiseTexture2D = NoiseTexture2D.new()
	bump.width = 1024
	bump.height = 2048
	bump.seamless = true
	bump.as_normal_map = true
	bump.bump_strength = 1.0
	var fine_noise: FastNoiseLite = FastNoiseLite.new()
	fine_noise.seed = 417
	fine_noise.frequency = 0.48
	bump.noise = fine_noise
	material.normal_enabled = true
	material.normal_texture = bump
	material.normal_scale = 0.15
	# Fine normal-map grain complements the full-field mowing texture.
	material.detail_enabled = false
	return material


func _build_field() -> void:
	var concrete: StandardMaterial3D = _material(Color("62665e"))
	_box(Vector3(0, -0.3, 50), Vector3(220, 0.45, 320), concrete, false)
	_box(Vector3(0, -0.055, 50), Vector3(68, 0.08, 138), _material(Color("30452b")), false)
	var plane: PlaneMesh = PlaneMesh.new()
	plane.size = Vector2(53.33, 120)
	var field: MeshInstance3D = MeshInstance3D.new()
	field.name = "NaturalGrassField"
	field.mesh = plane
	field.material_override = _grass_material()
	field.position = Vector3(0, 0.0, 50)
	field.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(field)
	_box(Vector3(0, 0.009, -5), Vector3(53.33, 0.014, 10), _material(Color("6e2535")), false)
	_box(Vector3(0, 0.009, 105), Vector3(53.33, 0.014, 10), _material(Color("192f45")), false)
	_endzone_labels.append(_ground_text(_home_name, 0, -5, minf(0.09, 0.46 / float(_home_name.length())), false))
	_endzone_labels.append(_ground_text(_away_name, 0, 105, minf(0.078, 0.46 / float(_away_name.length())), true))
	var paint: StandardMaterial3D = _material(Color("e3e4d5"), 0.96)
	var marks: Array[Transform3D] = []
	for z in range(0, 101, 5):
		marks.append(Transform3D(Basis.from_scale(Vector3(53.33, 0.012, 0.13 if z % 10 == 0 else 0.075)), Vector3(0, 0.024, z)))
	for x in [-26.67, 26.67]:
		marks.append(Transform3D(Basis.from_scale(Vector3(0.18, 0.012, 120)), Vector3(x, 0.025, 50)))
	for z in [-10, 110]:
		marks.append(Transform3D(Basis.from_scale(Vector3(53.33, 0.012, 0.18)), Vector3(0, 0.025, z)))
	for z in range(1, 100):
		for x in [-25.85, -8.89, 8.89, 25.85]:
			marks.append(Transform3D(Basis.from_scale(Vector3(0.52, 0.012, 0.055)), Vector3(x, 0.026, z)))
	for z in range(0, 101, 4):
		for x in [-28.4, 28.4]:
			marks.append(Transform3D(Basis.from_scale(Vector3(0.08, 0.012, 1.8)), Vector3(x, 0.027, z)))
	var unit_box: BoxMesh = BoxMesh.new()
	unit_box.size = Vector3.ONE
	_multimesh("PaintedYardLines", unit_box, paint, marks, [])
	for z in range(10, 100, 10):
		var number: String = str(mini(z, 100 - z))
		var left_number: Label3D = _ground_text(number, -20.4, z, 0.026, false)
		var right_number: Label3D = _ground_text(number, 20.4, z, 0.026, true)
		left_number.rotation.y = -PI / 2.0
		right_number.rotation.y = PI / 2.0
	_build_midfield_crest()
	var goal: StandardMaterial3D = _material(Color("eac140"), 0.36, 0.35)
	for z in [-10.5, 110.5]:
		var base: MeshInstance3D = _cylinder(Vector3(0, 2.7, z), 0.085, 5.4, goal)
		base.name = "GoalPost"
		var bar: MeshInstance3D = _cylinder(Vector3(0, 5.4, z), 0.07, 6.2, goal)
		bar.rotation.z = PI / 2.0
		for x in [-3.05, 3.05]:
			_cylinder(Vector3(x, 7.45, z), 0.065, 4.2, goal)
	var orange: StandardMaterial3D = _material(Color("ef732e"))
	for x in [-26.6, 26.6]:
		for z in [-10, 0, 100, 110]:
			_box(Vector3(x, 0.23, z), Vector3(0.15, 0.46, 0.15), orange)


func _build_midfield_crest() -> void:
	var edge: PackedVector3Array = PackedVector3Array([
		Vector3(-5.6, 0.032, 45.5), Vector3(5.6, 0.032, 45.5),
		Vector3(5.1, 0.032, 51.8), Vector3(0, 0.032, 55.1), Vector3(-5.1, 0.032, 51.8)
	])
	var tool: SurfaceTool = SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(edge.size()):
		tool.set_normal(Vector3.UP)
		tool.add_vertex(Vector3(0, 0.032, 49.5))
		tool.set_normal(Vector3.UP)
		tool.add_vertex(edge[i])
		tool.set_normal(Vector3.UP)
		tool.add_vertex(edge[(i + 1) % edge.size()])
	var crest: MeshInstance3D = MeshInstance3D.new()
	crest.mesh = tool.commit()
	crest.material_override = _material(Color("72263b"), 0.95)
	crest.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(crest)
	for i in range(edge.size()):
		var start: Vector3 = edge[i]
		var finish: Vector3 = edge[(i + 1) % edge.size()]
		var bar: MeshInstance3D = _box((start + finish) * 0.5 + Vector3(0, 0.003, 0), Vector3(0.13, 0.006, start.distance_to(finish)), _material(Color("d8c5a0")), false)
		bar.rotation.y = atan2(finish.x - start.x, finish.z - start.z)
	_ground_text("SL", 0, 49.7, 0.073, true, Color("e9d9b7"))


func _oval(theta: float, radius_x: float, radius_z: float, y: float) -> Vector3:
	var c: float = cos(theta)
	var s: float = sin(theta)
	return Vector3(signf(c) * pow(absf(c), 0.66) * radius_x, y, 50.0 + signf(s) * pow(absf(s), 0.66) * radius_z)


func _ring_surface(rx: float, rz: float, width: float, y: float, material: Material) -> void:
	var tool: SurfaceTool = SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(128):
		var a: float = TAU * float(i) / 128.0
		var b: float = TAU * float(i + 1) / 128.0
		var points: Array[Vector3] = [_oval(a, rx, rz, y), _oval(b, rx, rz, y), _oval(b, rx + width, rz + width, y), _oval(a, rx + width, rz + width, y)]
		for index in [0, 2, 1, 0, 3, 2]:
			tool.set_normal(Vector3.UP)
			tool.add_vertex(points[index])
	var instance: MeshInstance3D = MeshInstance3D.new()
	instance.mesh = tool.commit()
	instance.material_override = material
	add_child(instance)


func _ring_wall(rx: float, rz: float, y: float, height: float, material: Material) -> void:
	var tool: SurfaceTool = SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(128):
		var a: float = TAU * float(i) / 128.0
		var b: float = TAU * float(i + 1) / 128.0
		var normal: Vector3 = -Vector3(cos((a + b) * 0.5), 0, sin((a + b) * 0.5))
		var points: Array[Vector3] = [_oval(a, rx, rz, y), _oval(b, rx, rz, y), _oval(b, rx, rz, y + height), _oval(a, rx, rz, y + height)]
		for index in [0, 2, 1, 0, 3, 2]:
			tool.set_normal(normal)
			tool.add_vertex(points[index])
	var instance: MeshInstance3D = MeshInstance3D.new()
	instance.mesh = tool.commit()
	instance.material_override = material
	add_child(instance)


func _build_bowl() -> void:
	var tiers: Array[Vector4] = [Vector4(36, 76, 0.65, 22), Vector4(48.5, 88.5, 10.8, 22), Vector4(62, 102, 21.0, 18)]
	var stone: StandardMaterial3D = _material(Color("727772"))
	var riser: StandardMaterial3D = _material(Color("50595a"))
	var blue: StandardMaterial3D = _material(Color("1b2b38"), 0.64, 0.15)
	var trim: StandardMaterial3D = _material(Color("b5b7ac"), 0.42, 0.45)
	_ring_wall(34.5, 74.5, 0.0, 1.8, blue)
	for tier in tiers:
		for row in range(int(tier.w)):
			var rx: float = tier.x + row * 0.48
			var rz: float = tier.y + row * 0.48
			var y: float = tier.z + row * 0.38
			_ring_surface(rx, rz, 0.49, y, stone)
			_ring_wall(rx + 0.48, rz + 0.48, y, 0.38, riser)
		_ring_surface(tier.x + tier.w * 0.48, tier.y + tier.w * 0.48, 1.65, tier.z + tier.w * 0.38, stone)
		_ring_wall(tier.x, tier.y, tier.z - 0.4, 0.7, blue)
		_ring_wall(tier.x, tier.y, tier.z + 0.32, 0.08, trim)
		_ring_wall(tier.x + tier.w * 0.48 + 1.65, tier.y + tier.w * 0.48 + 1.65, tier.z + tier.w * 0.38, 1.1, blue)
	# Continuous LED ribbons and row separators visually bind all four sides.
	var led: StandardMaterial3D = _material(Color("6d2436"), 0.68)
	led.emission_enabled = true
	led.emission = Color("481824")
	led.emission_energy_multiplier = 0.35
	for tier in [Vector3(47.5, 87.5, 9.65), Vector3(61, 101, 19.9)]:
		_ring_wall(tier.x, tier.y, tier.z, 0.65, led)
		for i in range(14):
			var theta: float = TAU * (float(i) + 0.5) / 14.0
			var place: Vector3 = _oval(theta, tier.x - 0.07, tier.y - 0.07, tier.z + 0.31)
			var label: Label3D = _label("SATURDAY LIGHTS", place, 0.0105, Color("d5c8ac"))
			label.rotation.y = atan2(-place.x, 50.0 - place.z)
			label.shaded = false


func _multimesh(title: String, mesh: Mesh, material: Material, transforms: Array[Transform3D], colors: Array[Color]) -> MultiMeshInstance3D:
	var multimesh: MultiMesh = MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.use_colors = not colors.is_empty()
	multimesh.mesh = mesh
	multimesh.instance_count = transforms.size()
	for i in range(transforms.size()):
		multimesh.set_instance_transform(i, transforms[i])
		if not colors.is_empty():
			multimesh.set_instance_color(i, colors[i])
	var instance: MultiMeshInstance3D = MultiMeshInstance3D.new()
	instance.name = title
	instance.multimesh = multimesh
	instance.material_override = material
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)
	return instance


func _build_crowd() -> void:
	var bodies: Array[Transform3D] = []
	var heads: Array[Transform3D] = []
	var arms: Array[Transform3D] = []
	var body_colors: Array[Color] = []
	var head_colors: Array[Color] = []
	var arm_colors: Array[Color] = []
	var palette: Array[Color] = [Color("862a3c"), Color("a5414e"), Color("c9c7b6"), Color("d9d7cb"), Color("172e42"), Color("385a72"), Color("5d6b6c")]
	var skin: Array[Color] = [Color("ba8b6a"), Color("82563d"), Color("d2aa89"), Color("593b2e")]
	var tiers: Array[Vector4] = [Vector4(36, 76, 0.65, 22), Vector4(48.5, 88.5, 10.8, 22), Vector4(62, 102, 21.0, 18)]
	for tier_index in range(tiers.size()):
		var tier: Vector4 = tiers[tier_index]
		for row in range(int(tier.w)):
			var count: int = 268 + tier_index * 48 + row * 2
			for seat in range(count):
				if seat % 37 < 3 or _rng.randf() < 0.025:
					continue
				var theta: float = TAU * (float(seat) + 0.5) / float(count)
				var rx: float = tier.x + row * 0.48 + 0.22
				var rz: float = tier.y + row * 0.48 + 0.22
				var place: Vector3 = _oval(theta, rx, rz, tier.z + row * 0.38)
				var yaw: float = atan2(-place.x, 50.0 - place.z)
				var basis: Basis = Basis(Vector3.UP, yaw)
				var height: float = _rng.randf_range(0.90, 1.08)
				var body_basis: Basis = basis.scaled(Vector3(_rng.randf_range(0.87, 1.08), height, 1.0))
				var cloth_color: Color = palette[_rng.randi_range(0, palette.size() - 1)]
				if place.x > 0.0 and _rng.randf() < 0.58:
					cloth_color = palette[_rng.randi_range(0, 2)]
				bodies.append(Transform3D(body_basis, place + Vector3(0, 0.55 * height, 0)))
				body_colors.append(cloth_color)
				heads.append(Transform3D(basis.scaled(Vector3.ONE * _rng.randf_range(0.92, 1.08)), place + Vector3(0, 0.93 * height, 0)))
				head_colors.append(skin[_rng.randi_range(0, skin.size() - 1)])
				if seat % 11 == 0:
					for side in [-1, 1]:
						var arm_basis: Basis = basis * Basis(Vector3.FORWARD, float(side) * -0.4)
						arms.append(Transform3D(arm_basis, place + basis * Vector3(float(side) * 0.22, 0.97, 0)))
						arm_colors.append(cloth_color)
	var cloth: StandardMaterial3D = _material(Color.WHITE, 0.98).duplicate() as StandardMaterial3D
	cloth.vertex_color_use_as_albedo = true
	var flesh: StandardMaterial3D = _material(Color.WHITE, 0.9).duplicate() as StandardMaterial3D
	flesh.vertex_color_use_as_albedo = true
	var body_mesh: CapsuleMesh = CapsuleMesh.new()
	body_mesh.radius = 0.175
	body_mesh.height = 0.56
	body_mesh.radial_segments = 6
	body_mesh.rings = 1
	var head_mesh: SphereMesh = SphereMesh.new()
	head_mesh.radius = 0.11
	head_mesh.height = 0.22
	head_mesh.radial_segments = 6
	head_mesh.rings = 3
	var arm_mesh: CylinderMesh = CylinderMesh.new()
	arm_mesh.top_radius = 0.044
	arm_mesh.bottom_radius = 0.05
	arm_mesh.height = 0.42
	arm_mesh.radial_segments = 5
	_multimesh("SeatedCrowdClothing", body_mesh, cloth, bodies, body_colors)
	_multimesh("SeatedCrowdHeads", head_mesh, flesh, heads, head_colors)
	_multimesh("CheeringSpectatorArms", arm_mesh, cloth, arms, arm_colors)
	set_meta("spectator_count", bodies.size())


func _build_roofs_and_press() -> void:
	var structural: StandardMaterial3D = _material(Color("5a6265"), 0.56, 0.3)
	var trim: StandardMaterial3D = _material(Color("b5b9b7"), 0.4, 0.5)
	for side in [-1, 1]:
		var roof: MeshInstance3D = _box(Vector3(float(side) * 63, 31.4, 50), Vector3(35, 0.45, 161), structural)
		roof.rotation.z = float(side) * 0.065
		_box(Vector3(float(side) * 46.0, 30.2, 50), Vector3(0.35, 1.1, 161), trim)
		for z in [-18, 10, 38, 66, 94, 122]:
			_cylinder(Vector3(float(side) * 80, 15.3, z), 0.23, 30.6, structural)
			var brace: MeshInstance3D = _cylinder(Vector3(float(side) * 70, 29.0, z), 0.15, 20, trim)
			brace.rotation.z = float(side) * PI * 0.46
		_box(Vector3(float(side) * 76, 24.3, 50), Vector3(8, 6.5, 48), structural)
		var glass: StandardMaterial3D = _material(Color("36566c"), 0.2, 0.4)
		for z in range(28, 74, 4):
			_box(Vector3(float(side) * 71.8, 24.5, z), Vector3(0.1, 4.8, 3.65), glass)
			_box(Vector3(float(side) * 71.7, 24.5, z - 1.9), Vector3(0.16, 5.0, 0.12), trim)
		for z in [-12, 35, 80, 115]:
			_cylinder(Vector3(float(side) * 49, 20.0, z), 0.18, 40.0, structural)
			_box(Vector3(float(side) * 49, 40.0, z), Vector3(7, 1.1, 0.6), structural)
			var lamp: StandardMaterial3D = _material(Color("e7e6d4"), 0.2)
			lamp.emission_enabled = true
			lamp.emission = Color("fff2cd")
			lamp.emission_energy_multiplier = 0.7
			for i in range(5):
				_box(Vector3(float(side) * 49 - 2.6 + i * 1.3, 40.0, z - 0.38), Vector3(0.92, 0.7, 0.15), lamp, false)


func _build_scoreboards() -> void:
	var casing: StandardMaterial3D = _material(Color("17252f"), 0.5, 0.25)
	var screen: StandardMaterial3D = _material(Color("07141f"), 0.75)
	screen.emission_enabled = true
	screen.emission = Color("0b1d2b")
	screen.emission_energy_multiplier = 0.5
	for z in [-38.0, 138.0]:
		var sign: float = 1.0 if z < 0 else -1.0
		_box(Vector3(0, 22, z), Vector3(26, 9, 0.9), casing)
		_box(Vector3(0, 21.4, z + sign * 0.48), Vector3(24.7, 6.5, 0.05), screen, false)
		for x in [-9, 9]:
			_box(Vector3(x, 11.2, z + 0.5), Vector3(0.7, 22.4, 0.7), casing)
		var title: Label3D = _label("SATURDAY LIGHTS", Vector3(0, 25.3, z + sign * 0.5), 0.014, Color("d9c7a6"))
		var label: Label3D = _label("STATE  0 : 0  VALLEY\n3:00", Vector3(0, 21.6, z + sign * 0.53), 0.016, Color("f1f0e2"))
		title.shaded = false
		label.shaded = false
		if z > 0:
			title.rotation.y = PI
			label.rotation.y = PI
		_score_labels.append(label)


func _build_sidelines() -> void:
	var bodies: Array[Transform3D] = []
	var heads: Array[Transform3D] = []
	var legs: Array[Transform3D] = []
	var body_colors: Array[Color] = []
	var helmet_colors: Array[Color] = []
	var leg_colors: Array[Color] = []
	var white: StandardMaterial3D = _material(Color.WHITE, 0.8).duplicate() as StandardMaterial3D
	white.vertex_color_use_as_albedo = true
	var skin: StandardMaterial3D = _material(Color("a17657"))
	for side in [-1, 1]:
		for i in range(34):
			var z: float = 8.0 + float(i) * 2.55
			var position: Vector3 = Vector3(float(side) * (30.0 + _rng.randf_range(0, 0.65)), 0, z)
			var basis: Basis = Basis(Vector3.UP, -float(side) * PI / 2.0)
			bodies.append(Transform3D(basis, position + Vector3(0, 1.18, 0)))
			body_colors.append(Color("812a3e") if side < 0 else Color("e1e0d2"))
			heads.append(Transform3D(basis, position + Vector3(0, 1.73, 0)))
			helmet_colors.append(Color("6e2438") if side < 0 else Color("223f56"))
			for leg_side in [-1, 1]:
				legs.append(Transform3D(basis, position + basis * Vector3(float(leg_side) * 0.125, 0.5, 0)))
				leg_colors.append(Color("cccbbd") if side < 0 else Color("2a3d4b"))
		for z in [20, 42, 64, 86]:
			var bench: StandardMaterial3D = _material(Color("a9b0a7"), 0.5, 0.45)
			_box(Vector3(float(side) * 31.5, 0.65, z), Vector3(0.9, 0.16, 5.1), bench)
			_box(Vector3(float(side) * 31.8, 1.13, z), Vector3(0.1, 0.82, 5.1), bench)
			for offset in [-1.8, 1.8]:
				_box(Vector3(float(side) * 31.5, 0.3, z + offset), Vector3(0.7, 0.6, 0.12), bench)
			_box(Vector3(float(side) * 32.6, 0.5, z + 5), Vector3(0.8, 1.0, 0.8), _material(Color("d46b32")))
		for z in range(10, 100, 10):
			var marker: MeshInstance3D = _box(Vector3(float(side) * 28.5, 0.32, z), Vector3(0.12, 0.64, 0.7), _material(Color("df7b32")))
			var number: Label3D = _label(str(mini(z, 100 - z)), Vector3(float(side) * 28.42, 0.35, z), 0.0042, Color("182127"))
			number.rotation.y = -float(side) * PI / 2.0
			marker.name = "SidelineDistanceMarker"
	var body_mesh: CapsuleMesh = CapsuleMesh.new()
	body_mesh.radius = 0.21
	body_mesh.height = 0.66
	body_mesh.radial_segments = 8
	body_mesh.rings = 2
	var head_mesh: SphereMesh = SphereMesh.new()
	head_mesh.radius = 0.17
	head_mesh.height = 0.36
	head_mesh.radial_segments = 8
	head_mesh.rings = 4
	var leg_mesh: CapsuleMesh = CapsuleMesh.new()
	leg_mesh.radius = 0.09
	leg_mesh.height = 0.91
	leg_mesh.radial_segments = 6
	leg_mesh.rings = 1
	_multimesh("SidelineReserveJerseys", body_mesh, white, bodies, body_colors)
	_multimesh("SidelineReserveHelmets", head_mesh, white, heads, helmet_colors)
	_multimesh("SidelineReserveLegs", leg_mesh, white, legs, leg_colors)
	# A pair of identifiable chain-crew poles outside the playing surface.
	for z in [25, 35]:
		_cylinder(Vector3(-29.1, 1.3, z), 0.045, 2.6, _material(Color("e17b31")))
		var target: MeshInstance3D = _cylinder(Vector3(-29.1, 2.5, z), 0.28, 0.1, _material(Color("e17b31")))
		target.rotation.x = PI / 2.0


func update_score(home: int, away: int, seconds: int) -> void:
	var safe_seconds: int = maxi(0, seconds)
	var key: String = "%s:%s:%s:%s:%s" % [home, away, safe_seconds, _home_name, _away_name]
	_last_score = Vector3i(home, away, safe_seconds)
	if key == _score_key:
		return
	_score_key = key
	var clock: String = "%d:%02d" % [safe_seconds / 60, safe_seconds % 60]
	var score_line: String = "%s  %d : %d  %s" % [_home_name, home, away, _away_name]
	for label in _score_labels:
		label.pixel_size = minf(0.016, 0.42 / float(score_line.length()))
		label.text = score_line + "\n" + clock


func set_teams(home: String, away: String) -> void:
	_home_name = home.strip_edges().to_upper().left(18)
	_away_name = away.strip_edges().to_upper().left(18)
	if _home_name.is_empty():
		_home_name = "STATE"
	if _away_name.is_empty():
		_away_name = "VALLEY"
	if _endzone_labels.size() == 2:
		_endzone_labels[0].text = _home_name
		_endzone_labels[1].text = _away_name
		# Keep long college names inside the painted end-zone panel.
		_endzone_labels[0].pixel_size = minf(0.09, 0.46 / float(_home_name.length()))
		_endzone_labels[1].pixel_size = minf(0.078, 0.46 / float(_away_name.length()))
	update_score(_last_score.x, _last_score.y, _last_score.z)
