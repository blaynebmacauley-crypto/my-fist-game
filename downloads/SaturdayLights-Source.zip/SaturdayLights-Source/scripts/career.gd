class_name FootballCareer
extends RefCounted

## Local single-player career data. School names are real; every player,
## scholarship threshold, roster need and coach in this prototype is fictional.
const SAVE_VERSION: int = 1
const SAVE_FILE: String = "user://career.json"
const MAX_GAMES: int = 15
const POSITIONS: Array[String] = ["QB", "RB", "WR", "LB"]
const ATTRIBUTES: Array[String] = ["speed", "stamina", "throwing", "catching", "tackling", "blocking"]
const HIGH_SCHOOL_GAMES: Array[String] = ["Season Opener", "Rivalry Game", "State Championship"]
const UPGRADE_COSTS: Array[int] = [60, 100, 140]
const SCHOOLS: Array[Dictionary] = [
	{"name": "Georgia", "need": 4, "color": "#b01f36", "coach": "Coach Rivera (fictional)", "positions": ["LB", "RB"]},
	{"name": "Alabama", "need": 4, "color": "#9e1b32", "coach": "Coach Ellis (fictional)", "positions": ["QB", "LB"]},
	{"name": "Ohio State", "need": 4, "color": "#bb2438", "coach": "Coach Brooks (fictional)", "positions": ["WR", "RB"]},
	{"name": "Michigan", "need": 4, "color": "#163957", "coach": "Coach Carter (fictional)", "positions": ["RB", "LB"]},
	{"name": "Texas", "need": 3, "color": "#bf6532", "coach": "Coach Morgan (fictional)", "positions": ["QB", "WR"]},
	{"name": "Oregon", "need": 3, "color": "#146c48", "coach": "Coach Avery (fictional)", "positions": ["WR", "QB"]},
	{"name": "LSU", "need": 3, "color": "#58378c", "coach": "Coach Bennett (fictional)", "positions": ["LB", "WR"]},
	{"name": "Clemson", "need": 2, "color": "#e65e26", "coach": "Coach Davis (fictional)", "positions": ["QB", "LB"]},
	{"name": "Florida", "need": 2, "color": "#2659ac", "coach": "Coach Reed (fictional)", "positions": ["RB", "WR"]},
	{"name": "Tennessee", "need": 2, "color": "#ef8b23", "coach": "Coach Hayes (fictional)", "positions": ["WR", "RB"]},
	{"name": "Auburn", "need": 1, "color": "#243d60", "coach": "Coach Palmer (fictional)", "positions": ["QB", "RB", "WR", "LB"]},
	{"name": "Penn State", "need": 3, "color": "#233954", "coach": "Coach Porter (fictional)", "positions": ["LB", "RB"]},
]
const ARCHETYPES: Dictionary = {
	"QB": [
		{"id": "pocket-passer", "name": "Pocket Passer", "bonuses": {"throwing": 10, "stamina": 2, "speed": -3}},
		{"id": "dual-threat", "name": "Dual Threat", "bonuses": {"speed": 7, "throwing": 4}},
		{"id": "field-general", "name": "Field General", "bonuses": {"stamina": 8, "throwing": 6}},
	],
	"RB": [
		{"id": "power-back", "name": "Power Back", "bonuses": {"blocking": 10, "stamina": 6, "speed": -2}},
		{"id": "elusive-back", "name": "Elusive Back", "bonuses": {"speed": 8, "stamina": 4}},
		{"id": "workhorse", "name": "Workhorse", "bonuses": {"stamina": 12, "blocking": 4}},
	],
	"WR": [
		{"id": "route-runner", "name": "Route Runner", "bonuses": {"catching": 8, "stamina": 6}},
		{"id": "deep-threat", "name": "Deep Threat", "bonuses": {"speed": 9, "catching": 3}},
		{"id": "possession", "name": "Possession Receiver", "bonuses": {"catching": 12, "blocking": 3, "speed": -2}},
	],
	"LB": [
		{"id": "run-stopper", "name": "Run Stopper", "bonuses": {"tackling": 10, "blocking": 5}},
		{"id": "coverage", "name": "Coverage Linebacker", "bonuses": {"speed": 6, "stamina": 6}},
		{"id": "pass-rusher", "name": "Pass Rusher", "bonuses": {"tackling": 7, "speed": 5}},
	],
}


static func new_player(player_name: String, position: String, archetype: String = "") -> Dictionary:
	var role: String = position.to_upper()
	if not POSITIONS.has(role):
		role = "QB"
	var selected: String = _archetype_id(role, archetype)
	var upgrades: Dictionary = {}
	for attribute in ATTRIBUTES:
		upgrades[attribute] = 0
	var data: Dictionary = {
		"version": SAVE_VERSION, "name": _clean_name(player_name),
		"position": role, "archetype": selected, "high_school": "STATE HIGH SCHOOL",
		"highSchool": "STATE", "games": 0, "year": 0, "school": "", "stars": 0,
		"xp": 0, "xp_earned": 0, "xp_spent": 0, "trust": 45, "points": 0.0,
		"recruit_points": 0.0, "wins": 0, "practiced": -1, "upgrades": upgrades,
		"yards": 0, "td": 0, "completions": 0, "tackles": 0, "log": [],
	}
	_sync(data)
	return data


static func load_save() -> Dictionary:
	var path: String = SAVE_FILE
	if not FileAccess.file_exists(path):
		# Recover an interrupted replacement after the previous valid save was
		# moved aside but before the newly written file reached its final name.
		path = SAVE_FILE + ".bak"
		if not FileAccess.file_exists(path):
			return {}
	var file: FileAccess = FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {}
	var json: JSON = JSON.new()
	var parse_error: Error = json.parse(file.get_as_text())
	file.close()
	if parse_error != OK:
		return {}
	var parsed: Variant = json.data
	if not parsed is Dictionary or not _valid(parsed):
		return {}
	var data: Dictionary = parsed
	# JSON numbers are floats. Canonicalize integer fields before handing the
	# model to menus and game code; cached display fields are always recomputed.
	for key in ["version", "games", "xp", "xp_earned", "xp_spent", "trust", "wins", "practiced", "yards", "td", "completions", "tackles"]:
		data[key] = int(data[key])
	for attribute in ATTRIBUTES:
		data["upgrades"][attribute] = int(data["upgrades"].get(attribute, 0))
	_sync(data)
	return data


static func save(data: Dictionary) -> bool:
	if not _valid(data):
		return false
	_sync(data)
	var temporary: String = SAVE_FILE + ".tmp"
	var backup: String = SAVE_FILE + ".bak"
	var file: FileAccess = FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(data, "\t"))
	file.flush()
	var write_error: Error = file.get_error()
	file.close()
	if write_error != OK:
		DirAccess.remove_absolute(temporary)
		return false
	if FileAccess.file_exists(backup):
		DirAccess.remove_absolute(backup)
	var had_save: bool = FileAccess.file_exists(SAVE_FILE)
	if had_save and DirAccess.rename_absolute(SAVE_FILE, backup) != OK:
		DirAccess.remove_absolute(temporary)
		return false
	if DirAccess.rename_absolute(temporary, SAVE_FILE) != OK:
		if had_save:
			DirAccess.rename_absolute(backup, SAVE_FILE)
		return false
	if had_save:
		DirAccess.remove_absolute(backup)
	return true


static func complete_game(data: Dictionary, result: Dictionary) -> void:
	if not _valid(data) or not can_play(data) or not _valid_result(result):
		return
	var game_yards: int = roundi(float(result.get("yards", 0)))
	var game_td: int = int(result.get("td", 0))
	var game_completions: int = int(result.get("completions", result.get("comp", 0)))
	var game_tackles: int = int(result.get("tackles", 0))
	var home: int = int(result.get("home", 0))
	var away: int = int(result.get("away", 0))
	var won: bool = home > away
	var difficulty: float = clampf(float(result.get("difficulty", 1.0)), 0.65, 1.5)
	# Recruiting considers production, team success and the actual game's
	# difficulty. The recruiting grade freezes when the third HS game ends.
	var production: float = maxf(0.0, game_yards) * 0.12 + game_td * 12.0 + game_completions * 2.0 + game_tackles * 4.0
	var points: float = production * difficulty + (20.0 if won else 0.0)
	data["points"] = float(data["points"]) + points
	if int(data["games"]) < 3:
		data["recruit_points"] = float(data["recruit_points"]) + points
	data["games"] = int(data["games"]) + 1
	data["wins"] = int(data["wins"]) + (1 if won else 0)
	data["yards"] = int(data["yards"]) + game_yards
	data["td"] = int(data["td"]) + game_td
	data["completions"] = int(data["completions"]) + game_completions
	data["tackles"] = int(data["tackles"]) + game_tackles
	data["trust"] = clampi(int(data["trust"]) + (6 if won else 2) + (3 if game_completions >= 3 else 0), 0, 100)
	_earn(data, maxi(10, roundi(maxf(0.0, game_yards) + game_td * 50.0 + game_tackles * 15.0)))
	data["log"].append({
		"game": int(data["games"]), "yards": game_yards, "td": game_td,
		"completions": game_completions, "tackles": game_tackles,
		"home": home, "away": away, "difficulty": difficulty,
		"school": str(data["school"]),
	})
	_sync(data)


static func commit(data: Dictionary, school: String) -> bool:
	if not _valid(data) or int(data["games"]) != 3 or not str(data["school"]).is_empty():
		return false
	if not offers(data).has(school):
		return false
	data["school"] = school
	_sync(data)
	return true


static func buy_upgrade(data: Dictionary, attribute: String) -> bool:
	if not _valid(data) or int(data["games"]) < 1 or int(data["games"]) >= MAX_GAMES:
		return false
	if not _allowed_attributes(str(data["position"])).has(attribute):
		return false
	var level: int = int(data["upgrades"].get(attribute, 0))
	if level >= UPGRADE_COSTS.size():
		return false
	var cost: int = UPGRADE_COSTS[level]
	if int(data["xp"]) < cost:
		return false
	data["upgrades"][attribute] = level + 1
	data["xp_spent"] = int(data["xp_spent"]) + cost
	_sync(data)
	return true


static func practice(data: Dictionary) -> bool:
	if not _valid(data) or int(data["games"]) >= MAX_GAMES or int(data["practiced"]) == int(data["games"]):
		return false
	data["practiced"] = int(data["games"])
	data["trust"] = mini(100, int(data["trust"]) + 5)
	_earn(data, 20)
	_sync(data)
	return true


static func ratings(data: Dictionary) -> Dictionary:
	var role: String = str(data.get("position", "QB"))
	if not POSITIONS.has(role):
		role = "QB"
	var selected: String = _archetype_id(role, str(data.get("archetype", "")))
	var bonus: Dictionary = {}
	for entry in ARCHETYPES[role]:
		if str(entry["id"]) == selected:
			bonus = entry["bonuses"]
	var result: Dictionary = {}
	var upgrade_data: Dictionary = data.get("upgrades", {}) if data.get("upgrades", {}) is Dictionary else {}
	var allowed: Array[String] = _allowed_attributes(role)
	for attribute in ATTRIBUTES:
		var level: int = clampi(int(upgrade_data.get(attribute, 0)), 0, 3) if allowed.has(attribute) else 0
		result[attribute] = clampi(65 + int(bonus.get(attribute, 0)) + level * 4, 0, 100)
	return result


static func offers(data: Dictionary) -> Array[String]:
	var available: Array[String] = []
	if int(data.get("games", 0)) < 3:
		return available
	var grade: int = _stars(float(data.get("recruit_points", 0.0)))
	var role: String = str(data.get("position", "QB"))
	for school in SCHOOLS:
		# Recruiting needs are deliberately fictional and visibly identified in
		# school_info. A position need can lower a school's threshold by one star.
		var threshold: int = maxi(1, int(school["need"]) - (1 if school["positions"].has(role) and int(school["need"]) > 1 else 0))
		if grade >= threshold:
			available.append(str(school["name"]))
	return available


static func can_play(data: Dictionary) -> bool:
	var games: int = int(data.get("games", MAX_GAMES))
	return games >= 0 and games < MAX_GAMES and (games < 3 or not str(data.get("school", "")).is_empty())


static func upgrade_cost(data: Dictionary, attribute: String) -> int:
	if not _allowed_attributes(str(data.get("position", "QB"))).has(attribute):
		return -1
	var level: int = int(data.get("upgrades", {}).get(attribute, 0))
	return UPGRADE_COSTS[level] if level >= 0 and level < UPGRADE_COSTS.size() else -1


static func school_info(school_name: String) -> Dictionary:
	for school in SCHOOLS:
		if str(school["name"]) == school_name:
			return school.duplicate(true)
	return {}


static func _sync(data: Dictionary) -> void:
	var games: int = int(data.get("games", 0))
	data["xp"] = maxi(0, int(data.get("xp_earned", 0)) - int(data.get("xp_spent", 0)))
	data["stars"] = 0 if games < 3 else _stars(float(data.get("recruit_points", 0.0)))
	data["year"] = 0 if games < 3 else clampi(1 + int((games - 3) / 3), 1, 4)
	data["complete"] = games >= MAX_GAMES
	data["ratings"] = ratings(data)
	data["offers"] = offers(data)
	data["next_game"] = games + 1 if games < MAX_GAMES else 0
	data["depth_chart"] = "Starter" if int(data.get("trust", 45)) >= 65 else "Rotation / position battle"
	data["coach"] = "Coach Ellis (fictional)" if str(data.get("school", "")).is_empty() else str(school_info(str(data["school"])).get("coach", "Coach Morgan (fictional)"))
	if games < 3:
		data["stage"] = "High School · " + HIGH_SCHOOL_GAMES[games]
	elif games == 3 and str(data.get("school", "")).is_empty():
		data["stage"] = "National Signing Day · Choose a scholarship"
	elif games >= MAX_GAMES:
		data["stage"] = "Four condensed college seasons complete"
	else:
		data["stage"] = "College Year %d · Game %d of 3" % [int(data["year"]), (games - 3) % 3 + 1]
	data["national_rank"] = 0 if games < 3 else _recruit_rank(float(data.get("recruit_points", 0.0)))
	data["position_rank"] = 0 if games < 3 else maxi(1, ceili(float(data["national_rank"]) / 12.0))
	data["data_notice"] = "Real school names. Fictional players, coaches, recruiting rankings and roster needs."


static func _earn(data: Dictionary, amount: int) -> void:
	data["xp_earned"] = int(data.get("xp_earned", 0)) + maxi(0, amount)
	data["xp"] = int(data["xp_earned"]) - int(data.get("xp_spent", 0))


static func _allowed_attributes(role: String) -> Array[String]:
	var allowed: Array[String] = ["speed", "stamina"]
	match role:
		"QB": allowed.append("throwing")
		"RB": allowed.append("blocking")
		"WR": allowed.append("catching")
		"LB": allowed.append("tackling")
	return allowed


static func _archetype_id(role: String, requested: String) -> String:
	for entry in ARCHETYPES[role]:
		if requested.to_lower() == str(entry["id"]).to_lower() or requested.to_lower() == str(entry["name"]).to_lower():
			return str(entry["id"])
	return str(ARCHETYPES[role][0]["id"])


static func _clean_name(value: String) -> String:
	var result: String = ""
	for index in value.length():
		var point: int = value.unicode_at(index)
		if point >= 32 and point != 127:
			result += value[index]
	result = result.strip_edges().substr(0, 24)
	return "Jordan Hayes" if result.is_empty() else result


static func _stars(points: float) -> int:
	return clampi(1 + floori(maxf(0.0, points) / 35.0), 1, 5)


static func _recruit_rank(points: float) -> int:
	var grade: int = _stars(points)
	var ranges: Array[Vector2i] = [Vector2i(5000, 3001), Vector2i(3000, 1501), Vector2i(1500, 401), Vector2i(400, 121), Vector2i(120, 1)]
	var band: Vector2i = ranges[grade - 1]
	var fraction: float = clampf((points - float(grade - 1) * 35.0) / (210.0 if grade == 5 else 35.0), 0.0, 1.0)
	return roundi(lerpf(float(band.x), float(band.y), fraction))


static func _whole(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floorf(float(value))


static func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))


static func _valid_result(result: Dictionary) -> bool:
	for key in ["yards", "td", "completions", "comp", "tackles", "home", "away", "difficulty"]:
		if result.has(key) and not _number(result[key]):
			return false
	for key in ["td", "completions", "comp", "tackles", "home", "away"]:
		if result.has(key) and (not _whole(result[key]) or float(result[key]) < 0.0):
			return false
	return true


static func _valid(data: Dictionary) -> bool:
	if data.get("version", 0) != SAVE_VERSION or not data.get("name", null) is String or _clean_name(data["name"]) != data["name"]:
		return false
	if not POSITIONS.has(data.get("position", "")) or not data.get("archetype", null) is String:
		return false
	if _archetype_id(str(data["position"]), str(data["archetype"])) != data["archetype"]:
		return false
	for key in ["games", "xp", "xp_earned", "xp_spent", "trust", "wins", "practiced", "yards", "td", "completions", "tackles"]:
		if not _whole(data.get(key, null)):
			return false
	var games: int = int(data["games"])
	if games < 0 or games > MAX_GAMES or int(data["trust"]) < 0 or int(data["trust"]) > 100:
		return false
	if int(data["wins"]) < 0 or int(data["wins"]) > games or int(data["practiced"]) < -1 or int(data["practiced"]) > games:
		return false
	for key in ["xp", "xp_earned", "xp_spent", "td", "completions", "tackles"]:
		if int(data[key]) < 0:
			return false
	for key in ["points", "recruit_points"]:
		if not _number(data.get(key, null)) or float(data[key]) < 0.0:
			return false
	if not data.get("school", null) is String:
		return false
	var school: String = str(data["school"])
	if not school.is_empty() and school_info(school).is_empty():
		return false
	if games < 3 and not school.is_empty() or games > 3 and school.is_empty():
		return false
	if not data.get("log", null) is Array or data["log"].size() != games or not data.get("upgrades", null) is Dictionary:
		return false
	for entry in data["log"]:
		if not entry is Dictionary or not _valid_result(entry):
			return false
	var spent: int = 0
	var allowed: Array[String] = _allowed_attributes(str(data["position"]))
	for key in data["upgrades"]:
		if not ATTRIBUTES.has(key):
			return false
	for attribute in ATTRIBUTES:
		var level: Variant = data["upgrades"].get(attribute, 0)
		if not _whole(level) or int(level) < 0 or int(level) > 3 or int(level) > 0 and not allowed.has(attribute):
			return false
		for index in int(level):
			spent += UPGRADE_COSTS[index]
	return spent == int(data["xp_spent"]) and int(data["xp_earned"]) >= spent and int(data["xp"]) == int(data["xp_earned"]) - spent
