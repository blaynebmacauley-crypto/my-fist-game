class_name FootballHUD
extends CanvasLayer

signal quick_play(position: String)
signal new_career(athlete_name: String, position: String, archetype: String)
signal continue_career()
signal play_career()
signal commit_school(school: String)
signal upgrade(attribute: String)
signal menu()
signal snap()
signal pass_requested(target: int)
signal skill(side: int)
signal pause_requested(paused: bool)
signal play_selected(id: String)

const INK = Color("07131e")
const PANEL = Color("102532")
const PALE = Color("eaf2f5")
const MUTED = Color("9bb0bd")
const GOLD = Color("f4bd65")
const TEAL = Color("7ae0d6")
const SCHOOLS = ["Georgia", "Alabama", "Ohio State", "Michigan", "Texas", "Oregon", "LSU", "Clemson", "Florida", "Tennessee", "Auburn", "Penn State"]
const ROLES = ["QB", "RB", "WR", "LB"]
const ROLE_NAMES = {"QB":"QUARTERBACK", "RB":"RUNNING BACK", "WR":"WIDE RECEIVER", "LB":"LINEBACKER"}
const ROLE_NOTES = {
	"QB":"Read the defense. Lead your receivers, or escape the pocket. Forward passes stop after crossing the line of scrimmage.",
	"RB":"Follow your blocks, find the cutback and turn a crease into a big run. Time a juke before contact.",
	"WR":"Run your route, create separation and call for the ball. Track the pass, then turn upfield.",
	"LB":"Read the backfield, protect your gap and close on the ball. Blitz, cover or tackle the runner."
}
const ARCHETYPES = {
	"QB":[["pocket-passer", "Pocket Passer"], ["dual-threat", "Dual Threat"], ["field-general", "Field General"]],
	"RB":[["elusive-back", "Elusive Back"], ["power-back", "Power Back"], ["workhorse", "Workhorse"]],
	"WR":[["deep-threat", "Deep Threat"], ["route-runner", "Route Runner"], ["possession", "Possession Receiver"]],
	"LB":[["run-stopper", "Run Stopper"], ["pass-rusher", "Pass Rusher"], ["coverage", "Coverage Linebacker"]]
}

var _built = false
var _root: Control
var _home: Control
var _creator: Control
var _career_screen: Control
var _match: Control
var _result: Control
var _pause: Control
var _notice: Label
var _notice_time = 0.0
var _home_continue: Button
var _home_position: OptionButton
var _position_note: Label
var _creator_step = 0
var _creator_heading: Label
var _creator_identity: Control
var _creator_position_page: Control
var _creator_review_page: Control
var _creator_name: LineEdit
var _creator_position: OptionButton
var _creator_archetype: OptionButton
var _creator_role_note: Label
var _creator_review: Label
var _creator_back: Button
var _creator_next: Button
var _creator_steps: Label
var _career_data: Dictionary = {}
var _career_title: Label
var _career_subtitle: Label
var _career_metrics: Label
var _career_content: VBoxContainer
var _career_tabs: Array[Button] = []
var _career_tab = 0
var _career_scroll: ScrollContainer
var _home_score: Label
var _away_score: Label
var _home_team: Label
var _away_team: Label
var _clock: Label
var _down: Label
var _phase: Label
var _position_status: Label
var _play_status: Label
var _stats: Label
var _challenge: Label
var _stamina: ProgressBar
var _snap_button: Button
var _pass_buttons: Array[Button] = []
var _cut_left: Button
var _cut_right: Button
var _result_title: Label
var _result_body: Label
var _play_picker: OptionButton
var _picker_role = ""

func _ready() -> void:
	build()

func build() -> void:
	if _built:
		return
	_built = true
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 10
	_root = Control.new()
	_root.name = "FootballInterface"
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)
	var theme = Theme.new()
	theme.default_font_size = 18
	_root.theme = theme
	_build_home()
	_build_creator()
	_build_career()
	_build_match()
	_build_result()
	_build_pause()
	_notice = _label("", 35, PALE)
	_notice.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_notice.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_notice.position = Vector2(-500, 148)
	_notice.size = Vector2(1000, 100)
	_notice.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
	_notice.add_theme_constant_override("shadow_offset_x", 2)
	_notice.add_theme_constant_override("shadow_offset_y", 3)
	_notice.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_notice)
	_hide_screens()

func _process(delta: float) -> void:
	if _notice_time > 0.0 and not _pause.visible:
		_notice_time = maxf(0.0, _notice_time - delta)
		if _notice_time <= 0.0:
			_notice.text = ""

func _box(color: Color, border: Color = Color("365061"), radius: int = 8) -> StyleBoxFlat:
	var style = StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	return style

func _label(text: String, size: int = 18, color: Color = PALE) -> Label:
	var label = Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label

func _button(text: String, callback: Callable, primary: bool = false) -> Button:
	var button = Button.new()
	button.text = text
	button.custom_minimum_size.y = 49
	button.alignment = HORIZONTAL_ALIGNMENT_LEFT
	button.add_theme_font_size_override("font_size", 16)
	button.add_theme_color_override("font_color", INK if primary else PALE)
	button.add_theme_color_override("font_hover_color", INK)
	button.add_theme_color_override("font_focus_color", INK if primary else PALE)
	button.add_theme_stylebox_override("normal", _box(GOLD if primary else PANEL, GOLD if primary else Color("365061"), 5))
	button.add_theme_stylebox_override("hover", _box(Color("ffe0a4"), GOLD, 5))
	button.add_theme_stylebox_override("pressed", _box(Color("b9d8d7"), TEAL, 5))
	button.add_theme_stylebox_override("focus", _box(Color(0,0,0,0), TEAL, 5))
	button.add_theme_stylebox_override("disabled", _box(Color("1b2a33"), Color("2b3c47"), 5))
	button.add_theme_color_override("font_disabled_color", Color("6e8491"))
	button.pressed.connect(callback)
	return button

func _eyebrow(text: String) -> Label:
	return _label(text, 13, GOLD)

func _space(height: float) -> Control:
	var spacer = Control.new()
	spacer.custom_minimum_size.y = height
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return spacer

func _column(parent: Node, separation: int = 14) -> VBoxContainer:
	var box = VBoxContainer.new()
	box.add_theme_constant_override("separation", separation)
	parent.add_child(box)
	return box

func _screen() -> Control:
	var screen = Control.new()
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.add_child(screen)
	return screen

func _shade(parent: Node, alpha: float = 0.8) -> void:
	var shade = ColorRect.new()
	shade.color = Color(0.018, 0.045, 0.07, alpha)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	parent.add_child(shade)

func _page_margin(parent: Node, left: int = 58, top: int = 45, right: int = 58, bottom: int = 40) -> MarginContainer:
	var margin = MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", left)
	margin.add_theme_constant_override("margin_top", top)
	margin.add_theme_constant_override("margin_right", right)
	margin.add_theme_constant_override("margin_bottom", bottom)
	parent.add_child(margin)
	return margin

func _panel(parent: Node) -> PanelContainer:
	var panel = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _box(Color(0.035, 0.09, 0.13, 0.96)))
	parent.add_child(panel)
	return panel

func _options(items: Array) -> OptionButton:
	var options = OptionButton.new()
	options.custom_minimum_size.y = 48
	options.add_theme_font_size_override("font_size", 18)
	options.add_theme_stylebox_override("normal", _box(Color("152d3d")))
	options.add_theme_stylebox_override("focus", _box(Color("152d3d"), TEAL))
	for item in items:
		options.add_item(str(item))
	return options

func _build_home() -> void:
	_home = _screen()
	_shade(_home, 0.72)
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 60)
	_page_margin(_home).add_child(row)
	var left = _column(row, 8)
	left.custom_minimum_size.x = 440
	left.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left.add_child(_eyebrow("ROAD TO GLORY  /  NATIVE PC EDITION"))
	left.add_child(_label("SATURDAY\nLIGHTS", 42, PALE))
	left.add_child(_label("YOUR NAME. YOUR NUMBER.\nYOUR NEXT SATURDAY.", 17, GOLD))
	left.add_child(_space(4))
	left.add_child(_eyebrow("EXHIBITION POSITION"))
	_home_position = _options(ROLES)
	left.add_child(_home_position)
	_position_note = _label(ROLE_NOTES["QB"], 16, MUTED)
	_position_note.custom_minimum_size.y = 48
	left.add_child(_position_note)
	_home_position.item_selected.connect(func(index: int): _position_note.text = ROLE_NOTES[ROLES[index]])
	left.add_child(_button("PLAY EXHIBITION    →", func(): quick_play.emit(ROLES[_home_position.selected]), true))
	left.add_child(_button("CREATE YOUR ATHLETE    →", _open_creator))
	_home_continue = _button("CONTINUE CAREER    →", func(): continue_career.emit())
	left.add_child(_home_continue)
	var grow = Control.new()
	grow.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left.add_child(grow)
	left.add_child(_label("Fictional rosters and uniforms · Original game artwork", 12, MUTED))
	var right = _column(row, 18)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var filler = Control.new()
	filler.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(filler)
	var card = _column(_panel(right), 10)
	card.add_child(_eyebrow("THE ROAD STARTS HERE"))
	card.add_child(_label("THREE GAMES.\nONE CHANCE TO BE SEEN.", 30))
	card.add_child(_label("Season Opener  /  Rivalry  /  State Championship\nYour performance determines scholarship offers.", 17, MUTED))
	card.add_child(_space(4))
	card.add_child(_label("MOVE   WASD / LEFT STICK\nSPRINT   SHIFT / RT    ·    SNAP   SPACE / A\nPASS   1 / 2 / 3    ·    JUKE   Q / E\nWR CALL   1    ·    LB TACKLE   E\nPAUSE   ESC", 14, MUTED))

func _build_creator() -> void:
	_creator = _screen()
	_shade(_creator, 0.88)
	var outer = _column(_page_margin(_creator, 90, 44, 90, 40), 12)
	outer.add_child(_eyebrow("YOUR ROAD TO GLORY"))
	_creator_heading = _label("CREATE YOUR ATHLETE", 38)
	outer.add_child(_creator_heading)
	_creator_steps = _label("1  IDENTITY     /     2  POSITION     /     3  REVIEW", 14, GOLD)
	outer.add_child(_creator_steps)
	var content = _panel(outer)
	content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var pages = Control.new()
	pages.custom_minimum_size.y = 330
	content.add_child(pages)
	_creator_identity = VBoxContainer.new()
	_creator_identity.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_creator_identity.add_theme_constant_override("separation", 16)
	pages.add_child(_creator_identity)
	_creator_identity.add_child(_label("THE NAME ON THE JERSEY", 22))
	_creator_identity.add_child(_label("Take your time. Nothing starts until you save your athlete and choose to play.", 17, MUTED))
	_creator_name = LineEdit.new()
	_creator_name.text = "Jordan Hayes"
	_creator_name.max_length = 24
	_creator_name.custom_minimum_size.y = 54
	_creator_name.add_theme_font_size_override("font_size", 24)
	_creator_name.add_theme_stylebox_override("normal", _box(Color("152d3d")))
	_creator_identity.add_child(_creator_name)
	_creator_identity.add_child(_label("STATE HIGH SCHOOL\nYour high-school team stays the same throughout all three recruiting games.", 17, MUTED))
	_creator_position_page = VBoxContainer.new()
	_creator_position_page.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_creator_position_page.add_theme_constant_override("separation", 13)
	pages.add_child(_creator_position_page)
	_creator_position_page.add_child(_label("HOW DO YOU CHANGE A GAME?", 22))
	_creator_position = _options(ROLES)
	_creator_position_page.add_child(_creator_position)
	_creator_role_note = _label(ROLE_NOTES["QB"], 17, MUTED)
	_creator_role_note.custom_minimum_size.y = 58
	_creator_position_page.add_child(_creator_role_note)
	_creator_position_page.add_child(_eyebrow("ARCHETYPE"))
	_creator_archetype = _options([])
	_creator_position_page.add_child(_creator_archetype)
	_creator_position.item_selected.connect(_creator_role_changed)
	_creator_role_changed(0)
	_creator_review_page = VBoxContainer.new()
	_creator_review_page.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_creator_review_page.add_theme_constant_override("separation", 18)
	pages.add_child(_creator_review_page)
	_creator_review_page.add_child(_label("READY TO EARN YOUR SATURDAY?", 25))
	_creator_review = _label("", 22, GOLD)
	_creator_review_page.add_child(_creator_review)
	_creator_review_page.add_child(_label("Start unranked. Play three high-school games, earn college interest and choose your next team.\n\nYour career saves locally after completed games and upgrades.", 18, MUTED))
	var actions = HBoxContainer.new()
	actions.add_theme_constant_override("separation", 16)
	outer.add_child(actions)
	_creator_back = _button("CANCEL", _creator_previous)
	_creator_back.custom_minimum_size.x = 180
	actions.add_child(_creator_back)
	_creator_next = _button("NEXT    →", _creator_advance, true)
	_creator_next.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions.add_child(_creator_next)

func _creator_role_changed(index: int) -> void:
	var role: String = ROLES[index]
	_creator_role_note.text = ROLE_NOTES[role]
	_creator_archetype.clear()
	for entry in ARCHETYPES[role]:
		_creator_archetype.add_item(entry[1])
		_creator_archetype.set_item_metadata(_creator_archetype.item_count - 1, entry[0])

func _open_creator() -> void:
	build()
	_hide_screens()
	_creator.visible = true
	_creator_step = 0
	_show_creator_step()
	_creator_name.grab_focus()

func _show_creator_step() -> void:
	_creator_identity.visible = _creator_step == 0
	_creator_position_page.visible = _creator_step == 1
	_creator_review_page.visible = _creator_step == 2
	_creator_back.text = "CANCEL" if _creator_step == 0 else "←  BACK"
	_creator_next.text = "SAVE ATHLETE & ENTER CAREER    →" if _creator_step == 2 else "NEXT    →"
	_creator_steps.text = ["●  IDENTITY     /     2  POSITION     /     3  REVIEW", "✓  IDENTITY     /     ●  POSITION     /     3  REVIEW", "✓  IDENTITY     /     ✓  POSITION     /     ●  REVIEW"][_creator_step]
	if _creator_step == 2:
		var athlete_name = _creator_name.text.strip_edges()
		if athlete_name.is_empty(): athlete_name = "Jordan Hayes"
		_creator_review.text = athlete_name.to_upper() + "\n" + ROLE_NAMES[ROLES[_creator_position.selected]] + "  /  " + _creator_archetype.get_item_text(_creator_archetype.selected) + "\nSTATE HIGH SCHOOL  /  UNRANKED PROSPECT"

func _creator_previous() -> void:
	if _creator_step == 0:
		show_home(_home_continue.visible)
	else:
		_creator_step -= 1
		_show_creator_step()

func _creator_advance() -> void:
	if _creator_step < 2:
		_creator_step += 1
		_show_creator_step()
		_creator_next.grab_focus()
	else:
		var athlete_name = _creator_name.text.strip_edges()
		if athlete_name.is_empty(): athlete_name = "Jordan Hayes"
		new_career.emit(athlete_name, ROLES[_creator_position.selected], str(_creator_archetype.get_item_metadata(_creator_archetype.selected)))

func _build_career() -> void:
	_career_screen = _screen()
	_shade(_career_screen, 0.94)
	var outer = _column(_page_margin(_career_screen, 70, 35, 70, 30), 12)
	var header = HBoxContainer.new()
	header.add_theme_constant_override("separation", 24)
	outer.add_child(header)
	var titles = _column(header, 4)
	titles.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	titles.add_child(_eyebrow("ROAD TO GLORY"))
	_career_title = _label("YOUR ATHLETE", 36)
	titles.add_child(_career_title)
	_career_subtitle = _label("STATE HIGH SCHOOL", 16, MUTED)
	titles.add_child(_career_subtitle)
	var home_button = _button("HOME", func(): menu.emit())
	home_button.custom_minimum_size.x = 130
	header.add_child(home_button)
	_career_metrics = _label("", 18, GOLD)
	outer.add_child(_career_metrics)
	_career_scroll = ScrollContainer.new()
	_career_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_career_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(_career_scroll)
	_career_content = VBoxContainer.new()
	_career_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_career_content.add_theme_constant_override("separation", 14)
	_career_scroll.add_child(_career_content)
	var tabs = HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 10)
	outer.add_child(tabs)
	for i in range(3):
		var button = _button(["PLAY", "RECRUITMENT", "MY PLAYER"][i], _select_career_tab.bind(i))
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.alignment = HORIZONTAL_ALIGNMENT_CENTER
		tabs.add_child(button)
		_career_tabs.append(button)

func _select_career_tab(tab: int) -> void:
	_career_tab = tab
	_career_scroll.scroll_vertical = 0
	_render_career_tab()

func _clear_content() -> void:
	for child in _career_content.get_children():
		_career_content.remove_child(child)
		child.queue_free()

func _render_career_tab() -> void:
	_clear_content()
	for i in range(_career_tabs.size()):
		_career_tabs[i].add_theme_stylebox_override("normal", _box(GOLD if i == _career_tab else PANEL, GOLD if i == _career_tab else Color("365061"), 5))
		_career_tabs[i].add_theme_color_override("font_color", INK if i == _career_tab else MUTED)
	var games = int(_career_data.get("games", 0))
	var school = str(_career_data.get("school", ""))
	if _career_tab == 0:
		var card = _column(_panel(_career_content), 12)
		card.add_child(_eyebrow("GAME WEEK"))
		var heading = "SEASON OPENER" if games == 0 else "RIVALRY GAME" if games == 1 else "STATE CHAMPIONSHIP" if games == 2 else "COLLEGE GAME WEEK"
		if bool(_career_data.get("complete", false)): heading = "YOUR COLLEGE CAREER IS COMPLETE"
		card.add_child(_label(heading, 28))
		card.add_child(_label("Build your recruiting résumé in three high-school games." if games < 3 else "Sign with a college in Recruitment to begin the next chapter." if school.is_empty() else "Compete for " + school + ". Make every snap count.", 18, MUTED))
		var play = _button("PLAY NEXT GAME    →", func(): play_career.emit(), true)
		play.disabled = bool(_career_data.get("complete", false)) or (games >= 3 and school.is_empty())
		card.add_child(play)
		var coach = _column(_panel(_career_content), 10)
		coach.add_child(_eyebrow("COACH'S OFFICE"))
		coach.add_child(_label(str(_career_data.get("coach", "Coach Morgan  /  Player Development")), 21))
		var role = str(_career_data.get("position", "QB"))
		coach.add_child(_label(ROLE_NOTES.get(role, ROLE_NOTES["QB"]), 18, MUTED))
		var practice = _button("FILM SESSION  /  +20 XP · +5 TRUST", func(): upgrade.emit("practice"))
		practice.disabled = int(_career_data.get("practiced", -1)) == games or bool(_career_data.get("complete", false))
		if practice.disabled: practice.text = "FILM SESSION COMPLETE"
		coach.add_child(practice)
		coach.add_child(_label("Coach and recruitment details are fictional. Upgrades are available in My Player between games.", 13, MUTED))
	elif _career_tab == 1:
		_career_content.add_child(_label("NATIONAL SIGNING DAY" if games == 3 and school.is_empty() else "COLLEGE INTEREST", 27))
		_career_content.add_child(_label("Real school names. Fictional coaches, players, uniforms and scholarship offers.", 15, MUTED))
		var offers: Array = _career_data.get("offers", [])
		for program in SCHOOLS:
			var row = HBoxContainer.new()
			row.add_theme_constant_override("separation", 20)
			_panel(_career_content).add_child(row)
			var labels = _column(row, 4)
			labels.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			labels.add_child(_label(program, 23))
			labels.add_child(_label("COMMITTED" if school == program else "SCHOLARSHIP OFFER" if program in offers else "SCOUTING YOUR GAME", 14, TEAL if program in offers or school == program else MUTED))
			if games == 3 and school.is_empty() and program in offers:
				var sign = _button("COMMIT    →", _commit.bind(program), true)
				sign.custom_minimum_size.x = 200
				row.add_child(sign)
	else:
		var profile = _column(_panel(_career_content), 8)
		profile.add_child(_eyebrow("YOUR ATHLETE"))
		profile.add_child(_label(str(_career_data.get("name", "Jordan Hayes")).to_upper() + "  /  " + str(_career_data.get("position", "QB")), 29))
		profile.add_child(_label(str(_career_data.get("archetype", "field-general")).replace("-", " ").to_upper(), 17, GOLD))
		profile.add_child(_label("DEVELOPMENT", 23))
		profile.add_child(_label("Spend earned XP between games. Your attributes carry into the next kickoff.", 16, MUTED))
		var ratings: Dictionary = _career_data.get("ratings", {})
		var specialty = {"QB":"throwing", "RB":"blocking", "WR":"catching", "LB":"tackling"}.get(str(_career_data.get("position", "QB")), "throwing")
		for attribute in ["speed", "stamina", specialty]:
			var row = HBoxContainer.new()
			row.add_theme_constant_override("separation", 20)
			_panel(_career_content).add_child(row)
			var value = _label(str(attribute).to_upper() + "    " + str(ratings.get(attribute, 65)), 21)
			value.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			row.add_child(value)
			var levels: Dictionary = _career_data.get("upgrades", {})
			var level = int(levels.get(attribute, 0))
			var cost = [60, 100, 140][clampi(level, 0, 2)]
			var purchase = _button("MAX LEVEL" if level >= 3 else "UPGRADE  /  " + str(cost) + " XP", _purchase_upgrade.bind(attribute))
			purchase.custom_minimum_size.x = 200
			purchase.disabled = games == 0 or bool(_career_data.get("complete", false)) or level >= 3 or int(_career_data.get("xp", 0)) < cost
			row.add_child(purchase)

func _commit(school: String) -> void:
	commit_school.emit(school)

func _purchase_upgrade(attribute: String) -> void:
	upgrade.emit(attribute)

func _fixed_label(parent: Node, text: String, font_size: int, color: Color, rect: Rect2, alignment: int = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var label = _label(text, font_size, color)
	label.autowrap_mode = TextServer.AUTOWRAP_OFF
	label.clip_text = true
	label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	label.position = rect.position
	label.size = rect.size
	label.horizontal_alignment = alignment
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	parent.add_child(label)
	return label

func _flat_panel(parent: Node, rect: Rect2, color: Color, border: Color) -> Panel:
	var panel = Panel.new()
	panel.position = rect.position
	panel.size = rect.size
	panel.add_theme_stylebox_override("panel", _box(color, border, 0))
	parent.add_child(panel)
	return panel

func _build_match() -> void:
	_match = _screen()
	_match.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var status = _column(_panel(_match), 5)
	var status_panel: Control = status.get_parent()
	status_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	status_panel.position = Vector2(24, 24)
	status_panel.custom_minimum_size = Vector2(320, 92)
	_position_status = _label("QB  /  STATE HIGH SCHOOL", 14, GOLD)
	_position_status.max_lines_visible = 1
	status.add_child(_position_status)
	_play_status = _label("READ THE DEFENSE", 14)
	_play_status.max_lines_visible = 1
	status.add_child(_play_status)
	_challenge = _label("", 12, MUTED)
	_challenge.max_lines_visible = 1
	status.add_child(_challenge)
	_play_picker = _options([])
	_play_picker.custom_minimum_size.y = 36
	_play_picker.add_theme_font_size_override("font_size", 13)
	_play_picker.item_selected.connect(func(index: int): play_selected.emit(str(_play_picker.get_item_metadata(index))))
	status.add_child(_play_picker)
	_stamina = ProgressBar.new()
	_stamina.custom_minimum_size.y = 4
	_stamina.show_percentage = false
	_stamina.max_value = 1.0
	_stamina.value = 1.0
	var track = StyleBoxFlat.new()
	track.bg_color = Color("243746")
	track.set_corner_radius_all(2)
	var fill = StyleBoxFlat.new()
	fill.bg_color = TEAL
	fill.set_corner_radius_all(2)
	_stamina.add_theme_stylebox_override("background", track)
	_stamina.add_theme_stylebox_override("fill", fill)
	status.add_child(_stamina)
	var help = _label("WASD MOVE   /   SHIFT SPRINT   /   SPACE SNAP\n1–3 PASS   /   Q–E JUKE   /   ESC PAUSE", 12, Color("deebee"))
	help.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	help.position = Vector2(-450, 28)
	help.size = Vector2(420, 50)
	help.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	help.add_theme_color_override("font_shadow_color", Color.BLACK)
	help.add_theme_constant_override("shadow_offset_x", 1)
	help.add_theme_constant_override("shadow_offset_y", 2)
	_match.add_child(help)
	# Explicit score-strip geometry prevents number labels from collapsing to
	# zero width and keeps the whole broadcast bug clear of the screen edge.
	var strip = Control.new()
	strip.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	strip.position = Vector2(-420, -100)
	strip.size = Vector2(840, 78)
	strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_match.add_child(strip)
	var home_panel = _flat_panel(strip, Rect2(0, 0, 270, 56), Color("7c2038"), Color("a9495f"))
	_home_team = _fixed_label(home_panel, "STATE", 20, PALE, Rect2(14, 0, 188, 56))
	_home_score = _fixed_label(home_panel, "0", 31, PALE, Rect2(207, 0, 49, 56), HORIZONTAL_ALIGNMENT_RIGHT)
	var middle = _flat_panel(strip, Rect2(270, 0, 300, 56), Color("e9eee9"), Color("e9eee9"))
	_clock = _fixed_label(middle, "3:00", 24, INK, Rect2(0, 0, 300, 31), HORIZONTAL_ALIGNMENT_CENTER)
	_down = _fixed_label(middle, "1ST & 10  /  BALL ON 25", 11, Color("294452"), Rect2(6, 29, 288, 23), HORIZONTAL_ALIGNMENT_CENTER)
	var away_panel = _flat_panel(strip, Rect2(570, 0, 270, 56), Color("15354a"), Color("376078"))
	_away_score = _fixed_label(away_panel, "0", 31, PALE, Rect2(14, 0, 49, 56))
	_away_team = _fixed_label(away_panel, "VALLEY", 20, PALE, Rect2(68, 0, 188, 56), HORIZONTAL_ALIGNMENT_RIGHT)
	var ticker = _flat_panel(strip, Rect2(0, 56, 840, 22), Color("06121bea"), Color("344854"))
	_phase = _fixed_label(ticker, "PRE-SNAP", 10, GOLD, Rect2(12, 0, 165, 22))
	_stats = _fixed_label(ticker, "0 YDS  /  0 TD", 10, PALE, Rect2(180, 0, 648, 22), HORIZONTAL_ALIGNMENT_RIGHT)
	var actions = HBoxContainer.new()
	actions.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	actions.position = Vector2(-565, -169)
	actions.size = Vector2(535, 49)
	actions.add_theme_constant_override("separation", 8)
	_match.add_child(actions)
	_snap_button = _button("SPACE  /  SNAP", func(): snap.emit(), true)
	actions.add_child(_snap_button)
	for i in range(3):
		var pass_button = _button(str(i + 1), _pass.bind(i))
		pass_button.custom_minimum_size.x = 54
		actions.add_child(pass_button)
		_pass_buttons.append(pass_button)
	_cut_left = _button("Q  ◂", func(): skill.emit(-1))
	actions.add_child(_cut_left)
	_cut_right = _button("E  ▸", func(): skill.emit(1))
	actions.add_child(_cut_right)

func _pass(target: int) -> void:
	pass_requested.emit(target)

func _build_result() -> void:
	_result = _screen()
	_shade(_result, 0.87)
	var outer = _column(_page_margin(_result, 150, 115, 150, 100), 22)
	outer.add_child(_eyebrow("THE NEXT CHAPTER"))
	_result_title = _label("FINAL WHISTLE", 43)
	outer.add_child(_result_title)
	_result_body = _label("", 22, MUTED)
	_result_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.add_child(_result_body)
	outer.add_child(_button("CONTINUE    →", func(): menu.emit(), true))

func _build_pause() -> void:
	_pause = _screen()
	_shade(_pause, 0.77)
	var center = CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_pause.add_child(center)
	var card = _column(_panel(center), 18)
	card.custom_minimum_size = Vector2(480, 280)
	card.add_child(_eyebrow("TAKE A BREATHER"))
	card.add_child(_label("PAUSED", 39))
	card.add_child(_label("Resume when you are ready for the next snap.", 17, MUTED))
	card.add_child(_button("RESUME    /    ESC", func(): pause_requested.emit(false), true))
	card.add_child(_button("RETURN HOME", func(): menu.emit()))

func _hide_screens() -> void:
	for screen in [_home, _creator, _career_screen, _match, _result, _pause]:
		screen.visible = false
	_notice.text = ""
	_notice_time = 0.0

func show_home(has_save: bool) -> void:
	build()
	_hide_screens()
	_home.visible = true
	_home_continue.visible = has_save
	_home_position.grab_focus()

func show_career(career: Dictionary) -> void:
	build()
	_hide_screens()
	_career_data = career.duplicate(true)
	_career_screen.visible = true
	_career_title.text = str(career.get("name", "Jordan Hayes")).to_upper()
	var games = int(career.get("games", 0))
	var school = str(career.get("school", ""))
	_career_subtitle.text = str(career.get("position", "QB")) + "  /  " + ("STATE HIGH SCHOOL" if games < 3 else "NATIONAL SIGNING DAY" if school.is_empty() else school.to_upper() + "  /  YEAR " + str(career.get("year", 1)))
	var stars = clampi(int(career.get("stars", 0)), 0, 5)
	_career_metrics.text = ("UNRANKED" if stars == 0 else "★".repeat(stars) + "☆".repeat(5 - stars)) + "     /     COACH TRUST  " + str(career.get("trust", 50)) + "     /     " + str(career.get("xp", 0)) + " XP AVAILABLE     /     " + str(games) + " GAMES PLAYED"
	_render_career_tab()
	_career_tabs[_career_tab].grab_focus()

func show_match() -> void:
	build()
	_hide_screens()
	_match.visible = true
	_picker_role = ""
	var focus = get_viewport().gui_get_focus_owner()
	if focus: focus.release_focus()

func show_result(title: String, body: String) -> void:
	build()
	_hide_screens()
	_result.visible = true
	_result_title.text = title
	_result_body.text = body

func update_match(info: Dictionary) -> void:
	build()
	_home_score.text = str(info.get("home", 0))
	_away_score.text = str(info.get("away", 0))
	_home_team.text = str(info.get("home_team", "STATE")).to_upper()
	_away_team.text = str(info.get("away_team", "VALLEY")).to_upper()
	var seconds = maxi(0, int(ceil(float(info.get("time", 180)))))
	_clock.text = str(int(seconds / 60.0)) + ":" + "%02d" % (seconds % 60)
	var down = clampi(int(info.get("down", 1)), 1, 4)
	_down.text = ["1ST", "2ND", "3RD", "4TH"][down - 1] + " & " + str(maxi(1, int(ceil(float(info.get("distance", 10)))))) + "  /  BALL ON " + str(int(round(float(info.get("spot", 25)))))
	var phase = str(info.get("phase", "ready")).to_lower()
	var live = phase in ["live", "run only"]
	_phase.text = phase.replace("_", " ").to_upper()
	var role = str(info.get("position", "QB"))
	var can_pass = bool(info.get("can_pass", true))
	if _picker_role != role:
		_set_play_options(role)
	_play_picker.visible = (phase == "ready" or phase == "pre_snap") and role != "LB"
	_play_status.visible = not _play_picker.visible
	_challenge.visible = not _play_picker.visible and not str(info.get("challenge", "")).is_empty()
	var crossed = bool(info.get("crossed_scrimmage", false)) and bool(info.get("has_ball", true))
	_position_status.text = role + "  /  " + ("RUN ONLY · LINE CROSSED" if role == "QB" and crossed and live else ROLE_NAMES.get(role, role))
	_play_status.text = str(info.get("play", "READ THE DEFENSE")).to_upper()
	_challenge.text = str(info.get("challenge", "SPACE TO SNAP  /  C TO CHANGE CAMERA"))
	_stamina.value = clampf(float(info.get("stamina", 1.0)), 0.0, 1.0)
	_stats.text = str(info.get("stats", "0 YDS  /  0 TD"))
	_snap_button.visible = phase == "ready" or phase == "pre_snap"
	for i in range(_pass_buttons.size()):
		_pass_buttons[i].visible = role == "QB" or (role == "WR" and i == 0)
		_pass_buttons[i].disabled = not live or (role == "QB" and not can_pass)
		_pass_buttons[i].text = "1  CALL" if role == "WR" else str(i + 1)
	_cut_left.visible = true
	_cut_right.visible = role != "LB"
	_cut_left.disabled = not live
	_cut_right.disabled = not live

func set_message(text: String, seconds: float = 2.0) -> void:
	build()
	_notice.text = text
	_notice_time = maxf(0.0, seconds)

func show_pause(paused: bool) -> void:
	build()
	_pause.visible = paused

func _set_play_options(role: String) -> void:
	_picker_role = role
	_play_picker.clear()
	var calls: Array = [["Coach's Choice", "COACH SELECTS THE PLAY"]]
	if role == "RB":
		calls += [["Inside Zone", "INSIDE ZONE"], ["Stretch Right", "STRETCH RIGHT"], ["Power Left", "POWER LEFT"], ["Counter", "COUNTER"], ["Draw", "DRAW"]]
	else:
		calls += [["Slants", "QUICK SLANT"], ["Out", "DEEP OUT"], ["Cross", "CROSSING ROUTES"], ["Curl", "CURL / FLAT"], ["Corner", "CORNER ROUTES"], ["Post", "DEEP POST"], ["Mesh", "MESH CROSSERS"], ["Screen", "SCREEN"]]
	for call in calls:
		_play_picker.add_item(call[1])
		_play_picker.set_item_metadata(_play_picker.item_count - 1, call[0])
