class_name FootballAthlete
extends CharacterBody3D

## A colliding football actor with a separately animated, editable athlete model.
## The game owns possession and rules; touching an actor never ends a down here.

const MODEL_PATH := "res://assets/athlete.glb"
const SKIN_COLORS: Array[Color] = [
	Color("b57c56"), Color("d5a27c"), Color("845438"),
	Color("593b2d"), Color("dcb395"), Color("714a34")
]
const ACTION_DURATIONS := {"throw": 0.65, "catch": 0.5, "tackle": 1.25}

var team: int = 0
var index: int = 0
var jersey_number: int = 7
var speed: float = 0.0
var role: String = "QB"
var home: Vector3 = Vector3.ZERO
var stumble: float = 0.0
var holding_ball: bool = false
var dominant_hand: String = "right"
var animation_player: AnimationPlayer
var model: Node3D
var downed: bool = false

var _setup_done: bool = false
var _model_ready: bool = false
var _animation_map: Dictionary = {}
var _action: String = ""
var _action_remaining: float = 0.0
var _model_bind_transform: Transform3D = Transform3D.IDENTITY
var _hand_right: Node3D
var _hand_left: Node3D
var _front_number: Label3D
var _back_number: Label3D
var _material_names: Array[String] = []
var _number_color := Color("fff6e8")

func _ready() -> void:
	_build_collision()

func setup(team_value: int, index_value: int, number_value: int = 7,
		team_color: Color = Color("7e1832")) -> void:
	team = team_value
	index = index_value
	jersey_number = clampi(number_value, 1, 99)
	_build_collision()
	if not _setup_done:
		_setup_done = true
		_load_visual()
	_set_materials(team_color)
	_update_numbers()
	reset_pose()

func _build_collision() -> void:
	if get_node_or_null("AthleteCollision") != null:
		return
	collision_layer = 1
	collision_mask = 3
	safe_margin = 0.015
	floor_snap_length = 0.12
	floor_stop_on_slope = true
	max_slides = 5
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.27
	capsule.height = 1.8
	var shape := CollisionShape3D.new()
	shape.name = "AthleteCollision"
	shape.position.y = 0.9
	shape.shape = capsule
	add_child(shape)

func _load_visual() -> void:
	if not ResourceLoader.exists(MODEL_PATH):
		_missing_model("Athlete model is not imported: " + MODEL_PATH)
		return
	var scene: PackedScene = load(MODEL_PATH) as PackedScene
	if scene == null:
		_missing_model("Athlete model could not be loaded.")
		return
	model = scene.instantiate() as Node3D
	if model == null:
		_missing_model("Athlete model has no 3D root.")
		return
	model.name = "AthleteVisual"
	add_child(model)
	_model_bind_transform = model.transform
	_model_ready = true
	animation_player = _find_animation_player(model)
	if animation_player != null:
		# The game advances animations in the same fixed update as movement so
		# pausing a down also freezes throws, catches and tackle poses.
		animation_player.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
		for clip_name in animation_player.get_animation_list():
			var full_name := String(clip_name)
			var lower_name := full_name.to_lower()
			for key in ["idle", "run", "carry", "throw", "catch", "tackle"]:
				if lower_name == key or lower_name.ends_with("/" + key) or lower_name.ends_with("_" + key):
					_animation_map[key] = full_name
					var animation: Animation = animation_player.get_animation(clip_name)
					animation.loop_mode = Animation.LOOP_LINEAR if key in ["idle", "run", "carry"] else Animation.LOOP_NONE
	_hand_right = model.find_child("hand_R", true, false) as Node3D
	_hand_left = model.find_child("hand_L", true, false) as Node3D
	for node_name in ["DefaultNumberFront", "DefaultNumberBack"]:
		var baked_number := model.find_child(node_name, true, false) as Node3D
		if baked_number != null:
			baked_number.hide()
	_make_numbers()

func _missing_model(message: String) -> void:
	push_error(message)
	var warning := Label3D.new()
	warning.name = "MissingAthleteAsset"
	warning.text = "ATHLETE ASSET MISSING"
	warning.position.y = 1.3
	warning.font_size = 32
	warning.pixel_size = 0.005
	warning.modulate = Color("ffb57d")
	warning.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(warning)

func _find_animation_player(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node as AnimationPlayer
	for child in node.get_children():
		var found := _find_animation_player(child)
		if found != null:
			return found
	return null

func _make_numbers() -> void:
	var front_anchor := model.find_child("jersey_front", true, false) as Node3D
	var back_anchor := model.find_child("jersey_back", true, false) as Node3D
	if front_anchor != null:
		_front_number = _number_label("FrontNumber", Vector3(0.0, 0.0, 0.002), 0.0, front_anchor)
	else:
		_front_number = _number_label("FrontNumber", Vector3(0.0, 1.23, 0.175), 0.0)
	if back_anchor != null:
		_back_number = _number_label("BackNumber", Vector3(0.0, 0.0, 0.002), 0.0, back_anchor)
	else:
		_back_number = _number_label("BackNumber", Vector3(0.0, 1.25, -0.155), PI)

func _number_label(label_name: String, at: Vector3, yaw: float, attach_to: Node3D = null) -> Label3D:
	var label := Label3D.new()
	label.name = label_name
	label.position = at
	label.rotation.y = yaw
	label.text = str(jersey_number)
	label.font_size = 80
	label.pixel_size = 0.0037
	label.outline_size = 3
	label.outline_modulate = Color(0.04, 0.05, 0.06, 0.5)
	label.modulate = _number_color
	label.no_depth_test = false
	label.shaded = true
	label.alpha_cut = Label3D.ALPHA_CUT_OPAQUE_PREPASS
	var label_parent: Node3D = attach_to if attach_to != null else self
	label_parent.add_child(label)
	return label

func _set_materials(team_color: Color) -> void:
	if model == null:
		return
	var luminance: float = team_color.r * 0.2126 + team_color.g * 0.7152 + team_color.b * 0.0722
	_number_color = Color("162532") if luminance > 0.58 else Color("fff6e8")
	_material_names.clear()
	var materials_for_actor: Dictionary = {}
	var all_nodes: Array[Node] = [model]
	all_nodes.append_array(model.find_children("*", "MeshInstance3D", true, false))
	for item in all_nodes:
		if not item is MeshInstance3D:
			continue
		var mesh_node := item as MeshInstance3D
		if mesh_node.mesh == null:
			continue
		mesh_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		for surface in range(mesh_node.mesh.get_surface_count()):
			var source: Material = mesh_node.get_active_material(surface)
			if source == null or not source is BaseMaterial3D:
				continue
			var material_name := source.resource_name
			var material: BaseMaterial3D
			if materials_for_actor.has(material_name):
				material = materials_for_actor[material_name] as BaseMaterial3D
			else:
				material = source.duplicate() as BaseMaterial3D
				materials_for_actor[material_name] = material
			if not _material_names.has(material_name):
				_material_names.append(material_name)
			var kind := material_name.to_lower()
			if kind.begins_with("jersey"):
				material.albedo_color = team_color
				material.roughness = 0.84
			elif kind.begins_with("helmet"):
				material.albedo_color = team_color
				material.roughness = 0.24
				material.metallic = 0.12
			elif kind.begins_with("pants"):
				material.albedo_color = Color("d6d3c5") if team == 0 else Color("26394d")
				material.roughness = 0.86
			elif kind.begins_with("skin"):
				material.albedo_color = SKIN_COLORS[posmod(index, SKIN_COLORS.size())]
				material.roughness = 0.68
			elif kind.begins_with("gloves"):
				material.albedo_color = Color("e6e9e3")
			elif kind.begins_with("facemask"):
				material.roughness = 0.32
				material.metallic = 0.58
			mesh_node.set_surface_override_material(surface, material)

func _update_numbers() -> void:
	for label in [_front_number, _back_number]:
		if label != null:
			label.text = str(jersey_number)
			label.modulate = _number_color

func set_team_color(value: Color) -> void:
	_set_materials(value)
	_update_numbers()

func set_ball_carrier(value: bool) -> void:
	holding_ball = value

func drive(desired: Vector3, delta: float) -> void:
	delta = maxf(0.0, delta)
	stumble = maxf(0.0, stumble - delta)
	var target := Vector3(desired.x, 0.0, desired.z)
	if target.length() > 12.0:
		target = target.normalized() * 12.0
	if stumble > 0.0:
		target *= 0.7
	if downed or _action == "tackle":
		target = Vector3.ZERO
	var acceleration: float = 24.0 if target.length_squared() > 0.01 else 30.0
	velocity.x = move_toward(velocity.x, target.x, acceleration * delta)
	velocity.z = move_toward(velocity.z, target.z, acceleration * delta)
	if not is_on_floor():
		velocity.y -= 9.8 * delta
	else:
		velocity.y = -0.15
	if delta > 0.0:
		move_and_slide()
	speed = Vector2(velocity.x, velocity.z).length()
	if speed > 0.15 and not downed and _action != "tackle":
		var yaw: float = atan2(velocity.x, velocity.z)
		rotation.y = lerp_angle(rotation.y, yaw, 1.0 - exp(-12.0 * delta))
	_tick_animation(delta)

func _tick_animation(delta: float) -> void:
	if animation_player == null:
		return
	if _action != "":
		if _action_remaining > 0.0:
			_action_remaining = maxf(0.0, _action_remaining - delta)
			animation_player.advance(delta)
		if _action_remaining <= 0.0:
			if _action == "tackle" or downed:
				_hold_action_end()
				return
			_action = ""
		else:
			return
	if downed:
		return
	var locomotion := "idle"
	if speed > 0.25:
		locomotion = "carry" if holding_ball and _animation_map.has("carry") else "run"
	var rate: float = clampf(speed / 5.7, 0.55, 1.5) if locomotion in ["run", "carry"] else 1.0
	_play_clip(locomotion, 0.15, rate)
	animation_player.advance(delta)

func _play_clip(action_name: String, blend: float = 0.1, rate: float = 1.0) -> void:
	if animation_player == null or not _animation_map.has(action_name):
		return
	var clip_name: StringName = StringName(_animation_map[action_name])
	animation_player.speed_scale = rate
	if animation_player.current_animation != clip_name or not animation_player.is_playing():
		animation_player.play(clip_name, blend, 1.0)
		if action_name in ["idle", "run", "carry"]:
			var clip: Animation = animation_player.get_animation(clip_name)
			if clip.length > 0.0:
				animation_player.seek(fposmod(float(index) * 0.113, clip.length), true)

func play_action(action_name: String) -> void:
	var normalized := action_name.to_lower()
	if _action == normalized and _action_remaining > 0.0:
		return
	if downed and normalized != "tackle":
		return
	_action = normalized
	_action_remaining = float(ACTION_DURATIONS.get(normalized, 0.5))
	if animation_player != null and _animation_map.has(normalized):
		var clip_name: StringName = StringName(_animation_map[normalized])
		var clip: Animation = animation_player.get_animation(clip_name)
		_action_remaining = maxf(0.1, clip.length)
		animation_player.speed_scale = 1.0
		animation_player.play(clip_name, 0.08, 1.0)
		animation_player.advance(0.0)

func set_down(value: bool = true) -> void:
	downed = value
	if value:
		velocity = Vector3.ZERO
		speed = 0.0
		if _action != "tackle":
			play_action("tackle")
		_action_remaining = 0.0
		_hold_action_end()
	else:
		reset_pose()

func _hold_action_end() -> void:
	if animation_player == null or not _animation_map.has(_action):
		return
	var clip_name: StringName = StringName(_animation_map[_action])
	var clip: Animation = animation_player.get_animation(clip_name)
	animation_player.seek(maxf(0.0, clip.length - 0.001), true)
	animation_player.pause()

func reset_pose() -> void:
	downed = false
	_action = ""
	_action_remaining = 0.0
	holding_ball = false
	stumble = 0.0
	velocity = Vector3.ZERO
	speed = 0.0
	rotation.x = 0.0
	rotation.z = 0.0
	if model != null:
		model.transform = _model_bind_transform
	if animation_player != null:
		animation_player.stop()
		if animation_player.has_animation("RESET"):
			animation_player.play("RESET")
			animation_player.advance(0.0)
			animation_player.stop()
		_play_clip("idle", 0.0, 1.0)
		animation_player.advance(0.0)

func ball_anchor() -> Vector3:
	var hand: Node3D = _hand_left if dominant_hand == "left" else _hand_right
	if hand != null and is_instance_valid(hand):
		return hand.to_global(Vector3(0.0, -0.025, 0.07))
	var side: float = -1.0 if dominant_hand == "left" else 1.0
	return to_global(Vector3(side * 0.25, 1.08, 0.13))

func get_visual_stats() -> Dictionary:
	var animation_names: Array[String] = []
	if animation_player != null:
		for clip in animation_player.get_animation_list():
			animation_names.append(String(clip))
	var mesh_count: int = 0
	if model != null:
		mesh_count = model.find_children("*", "MeshInstance3D", true, false).size()
	return {
		"loaded": _model_ready,
		"meshes": mesh_count,
		"animations": animation_names,
		"materials": _material_names.duplicate(),
		"hand_anchor": _hand_right != null,
		"downed": downed,
		"action": _action,
	}
