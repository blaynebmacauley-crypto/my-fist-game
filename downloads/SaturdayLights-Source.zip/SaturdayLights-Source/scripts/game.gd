extends Node3D
## Native football game. World distances are approximately yards; offense attacks +Z.
const AthleteScript = preload("res://scripts/athlete.gd")
const StadiumScript = preload("res://scripts/stadium.gd")
const HUDScript = preload("res://scripts/hud.gd")
const Career = preload("res://scripts/career.gd")
const HOME_COLOR := Color("7d203b")
const AWAY_COLOR := Color("e6e4d9")
const PASS_PLAYS := ["Slants", "Cross", "Out", "Curl", "Post", "Corner", "Mesh", "Screen"]
const RUN_PLAYS := ["Inside Zone", "Stretch Right", "Power Left", "Counter", "Draw"]
const DEF_X := [-4.0,-1.3,1.3,4.0,-7.0,0.0,7.0,-20.0,18.0,-9.0,9.0]
const DEF_Z := [1.0,1.0,1.0,1.0,4.8,4.8,4.8,3.8,3.8,13.0,13.0]
var stadium: Node3D
var hud: CanvasLayer
var camera: Camera3D
var actors: Array = []
var football: MeshInstance3D
var scrimmage: MeshInstance3D
var first_down_line: MeshInstance3D
var active_ring: MeshInstance3D
var pass_markers: Array[Label3D] = []
var mode := "home"
var phase := "ready"
var position_role := "QB"
var career: Dictionary = {}
var career_active := false
var attributes: Dictionary = {}
var paused := false
var wide_camera := false
var carrier := 0
var crossed_scrimmage := false
var pass_used := false
var requested_pass := false
var flight: Dictionary = {}
var play_time := 0.0
var game_clock := 180.0
var home_score := 0
var away_score := 0
var spot := 25.0
var down := 1
var line_to_gain := 35.0
var snap_spot := 25.0
var play_sequence := 0
var chosen_play := "Coach's Choice"
var current_play := "Slants"
var is_run := false
var dead_timer := 0.0
var runoff := 0.0
var pending_possession := false
var simulation: Dictionary = {}
var tackle: Dictionary = {}
var tackle_cooldowns: Array[float] = []
var stamina := 1.0
var catch_grace := 0.0
var skill: Dictionary = {}
var skill_cooldown := 0.0
var user_tackle_cooldown := 0.0
var overcommit: Dictionary = {}
var stats: Dictionary = {}
var rng := RandomNumberGenerator.new()
var home_team := "STATE HIGH"
var away_team := "VALLEY HIGH"
var last_recap := ""
var ready_complete := false
var screenshot_frames := 0

func _ready() -> void:
	rng.randomize()
	_install_inputs()
	stadium = StadiumScript.new()
	add_child(stadium)
	stadium.build()
	_make_floor()
	_make_ball_and_markers()
	_spawn_athletes()
	camera = Camera3D.new()
	camera.fov = 47.0
	camera.far = 500.0
	camera.near = 0.15
	add_child(camera)
	camera.current = true
	hud = HUDScript.new()
	add_child(hud)
	hud.quick_play.connect(start_quick_play)
	hud.new_career.connect(_new_career)
	hud.continue_career.connect(_continue_career)
	hud.play_career.connect(_play_career)
	hud.commit_school.connect(_commit_school)
	hud.upgrade.connect(_upgrade)
	hud.menu.connect(_menu)
	hud.snap.connect(snap)
	hud.pass_requested.connect(_request_pass)
	hud.skill.connect(start_skill)
	if hud.has_signal("pause_requested"):
		hud.connect("pause_requested", _set_paused)
	if hud.has_signal("play_selected"):
		hud.connect("play_selected", _select_play)
	career = Career.load_save()
	attributes = Career.ratings(Career.new_player("Jordan Hayes", "QB"))
	_reset_stats()
	formation()
	hud.show_home(not career.is_empty())
	_update_camera(1.0, true)
	ready_complete = true
	# Optional visual verification uses the same native rendering as the game.
	if "--screenshot" in OS.get_cmdline_user_args():
		start_quick_play("QB")
		get_tree().create_timer(3.0).timeout.connect(_capture_screenshot)

func _install_inputs() -> void:
	var key_map := {"forward":[KEY_W,KEY_UP], "backward":[KEY_S,KEY_DOWN], "left":[KEY_A,KEY_LEFT], "right":[KEY_D,KEY_RIGHT], "sprint":[KEY_SHIFT], "snap":[KEY_SPACE], "pass_1":[KEY_1], "pass_2":[KEY_2], "pass_3":[KEY_3], "cut_left":[KEY_Q], "cut_right":[KEY_E], "pause_game":[KEY_ESCAPE,KEY_P], "camera_view":[KEY_C]}
	for action in key_map:
		if not InputMap.has_action(action): InputMap.add_action(action)
		for key in key_map[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action, event)
	var buttons := {"snap":JOY_BUTTON_A,"pass_1":JOY_BUTTON_X,"pass_2":JOY_BUTTON_Y,"pass_3":JOY_BUTTON_B,"cut_left":JOY_BUTTON_RIGHT_SHOULDER,"pause_game":JOY_BUTTON_START,"camera_view":JOY_BUTTON_LEFT_SHOULDER}
	for action in buttons:
		var button := InputEventJoypadButton.new()
		button.button_index = buttons[action]
		InputMap.action_add_event(action, button)
	for entry in [["left",JOY_AXIS_LEFT_X,-1.0],["right",JOY_AXIS_LEFT_X,1.0],["forward",JOY_AXIS_LEFT_Y,-1.0],["backward",JOY_AXIS_LEFT_Y,1.0],["sprint",JOY_AXIS_TRIGGER_RIGHT,1.0]]:
		var axis := InputEventJoypadMotion.new()
		axis.axis = entry[1]
		axis.axis_value = entry[2]
		InputMap.action_add_event(entry[0],axis)

func _make_floor() -> void:
	var floor_body := StaticBody3D.new()
	floor_body.collision_layer = 2
	floor_body.collision_mask = 1
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(180,1,230)
	shape.shape = box
	shape.position = Vector3(0,-0.52,50)
	floor_body.add_child(shape)
	add_child(floor_body)

func _make_ball_and_markers() -> void:
	football = MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.13
	sphere.height = 0.26
	sphere.radial_segments = 24
	sphere.rings = 12
	football.mesh = sphere
	football.scale = Vector3(1,1,1.85)
	var leather := StandardMaterial3D.new()
	leather.albedo_color = Color("6d3420")
	leather.roughness = 0.87
	football.material_override = leather
	add_child(football)
	for i in range(5):
		var lace := MeshInstance3D.new()
		var lace_mesh := BoxMesh.new()
		lace_mesh.size = Vector3(0.075,0.009,0.008)
		lace.mesh = lace_mesh
		var lace_mat := StandardMaterial3D.new()
		lace_mat.albedo_color = Color("eee3ce")
		lace.material_override = lace_mat
		lace.position = Vector3(0,0.126,(i-2)*0.025)
		football.add_child(lace)
	scrimmage = _field_line(Color(0.12,0.63,1.0,0.62))
	first_down_line = _field_line(Color(1.0,0.76,0.17,0.72))
	active_ring = MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.49
	torus.outer_radius = 0.55
	torus.rings = 40
	torus.ring_segments = 8
	active_ring.mesh = torus
	var ring_mat := StandardMaterial3D.new()
	ring_mat.albedo_color = Color("6ce7e4")
	ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	active_ring.material_override = ring_mat
	add_child(active_ring)
	for i in range(3):
		var marker := Label3D.new()
		marker.text = str(i+1)
		marker.font_size = 54
		marker.pixel_size = 0.009
		marker.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		marker.modulate = Color("ffe5aa")
		marker.outline_modulate = Color("172838")
		marker.outline_size = 12
		add_child(marker)
		pass_markers.append(marker)

func _field_line(color: Color) -> MeshInstance3D:
	var line := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(53.2,0.008,0.07)
	line.mesh = box
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	line.material_override = material
	add_child(line)
	return line

func _spawn_athletes() -> void:
	for index in range(22):
		var actor = AthleteScript.new()
		add_child(actor)
		actor.setup(0 if index<11 else 1,index,7 if index==0 else 60+index if index<6 else 75+index if index<11 else 20+index, HOME_COLOR if index<11 else AWAY_COLOR)
		actors.append(actor)
		tackle_cooldowns.append(0.0)

func _reset_stats() -> void:
	stats = {"yards":0.0,"td":0,"completions":0,"attempts":0,"tackles":0,"catches":0,"big_plays":0}

func start_quick_play(role: String) -> void:
	career_active = false
	position_role = role if role in ["QB","RB","WR","LB"] else "QB"
	attributes = Career.ratings(Career.new_player("Jordan Hayes",position_role))
	_start_game()

func _new_career(player_name: String,role: String,archetype: String) -> void:
	career = Career.new_player(player_name,role,archetype)
	career_active = true
	Career.save(career)
	_show_career()

func _continue_career() -> void:
	if not career.is_empty():
		career_active = true
		_show_career()

func _show_career() -> void:
	mode = "career"
	paused = false
	if not career.is_empty(): hud.show_career(career)

func _play_career() -> void:
	if career.is_empty() or not Career.can_play(career): return
	career_active = true
	position_role = str(career.get("position","QB"))
	attributes = Career.ratings(career)
	_start_game()

func _commit_school(school: String) -> void:
	if Career.commit(career,school):
		Career.save(career)
		_show_career()

func _upgrade(attribute: String) -> void:
	if attribute=="practice":
		Career.practice(career)
	else:
		Career.buy_upgrade(career,attribute)
	Career.save(career)
	_show_career()

func _menu() -> void:
	paused = false
	if career_active and mode=="result":
		_show_career()
	else:
		mode = "home"
		hud.show_home(not career.is_empty())

func _start_game() -> void:
	mode = "play"
	paused = false
	game_clock = 180.0
	home_score = 0
	away_score = 0
	spot = 25.0
	down = 1
	line_to_gain = 35.0
	play_sequence = 0
	chosen_play = "Coach's Choice"
	stamina = 1.0
	pending_possession = false
	simulation.clear()
	_reset_stats()
	home_team = str(career.get("school","STATE HIGH")) if career_active and int(career.get("games",0))>=3 else "STATE HIGH"
	if home_team.is_empty(): home_team = "STATE HIGH"
	var opponents := ["VALLEY HIGH","RIDGEVIEW HIGH","LAKESIDE HIGH"]
	if career_active and int(career.get("games",0))>=3:
		opponents = ["Georgia","Oregon","Texas","Clemson","Alabama","Michigan"]
	away_team = opponents[int(career.get("games",0))%opponents.size()]
	if away_team==home_team: away_team = "Ohio State"
	var own_color := HOME_COLOR
	if career_active and int(career.get("games",0))>=3:
		var school := Career.school_info(home_team)
		own_color = Color(str(school.get("color","7d203b")))
	if stadium.has_method("set_teams"): stadium.set_teams(home_team,away_team)
	for i in range(22):
		var is_own: bool = i>=11 if position_role=="LB" else i<11
		actors[i].setup(0 if i<11 else 1,i,7 if i==0 else 60+i if i<6 else 75+i if i<11 else 20+i,own_color if is_own else AWAY_COLOR)
	hud.show_match()
	formation()
	_update_camera(1.0,true)
	hud.set_message(position_role+" · "+current_game_name(),2.5)

func current_game_name() -> String:
	var games: int = int(career.get("games",0)) if career_active else 0
	if games<3: return ["SEASON OPENER","RIVALRY GAME","STATE CHAMPIONSHIP"][games]
	return "COLLEGE YEAR %d · GAME %d" % [1+(games-3)/3,1+(games-3)%3]

func _select_play(play: String) -> void:
	if phase!="ready" or position_role=="LB": return
	chosen_play = play
	formation()

func formation() -> void:
	phase = "ready"
	carrier = 0
	crossed_scrimmage = false
	pass_used = false
	requested_pass = false
	flight.clear()
	tackle.clear()
	skill.clear()
	skill_cooldown = 0.0
	catch_grace = 0.0
	overcommit.clear()
	play_time = 0.0
	snap_spot = spot
	is_run = position_role=="RB" or (position_role=="LB" and play_sequence%2==0)
	current_play = RUN_PLAYS[play_sequence%RUN_PLAYS.size()] if is_run else PASS_PLAYS[play_sequence%PASS_PLAYS.size()]
	if chosen_play!="Coach's Choice" and position_role!="LB":
		current_play = chosen_play
		is_run = current_play in RUN_PLAYS
	for i in range(22):
		var x := 0.0
		var z: float = spot
		if i==0: z-=4.0
		elif i<6:
			x=(i-3)*1.5
			z-=0.6
		elif i<9:
			x=[-20.0,18.0,-11.0][i-6]
			z-=1.0
		elif i==9:
			x=4.0
			z-=4.0
		elif i==10:
			x=-3.0
			z-=5.0
		else:
			x=DEF_X[i-11]
			z+=DEF_Z[i-11]*minf(1.0,(108.0-spot)/15.0)
		actors[i].global_position=Vector3(x,0.03,z)
		actors[i].home=Vector3(x,0.03,z)
		actors[i].rotation=Vector3(0,PI if i>=11 else 0.0,0)
		actors[i].velocity=Vector3.ZERO
		actors[i].reset_pose()
		tackle_cooldowns[i]=0.0
	scrimmage.position=Vector3(0,0.035,spot)
	first_down_line.position=Vector3(0,0.036,line_to_gain)
	_update_hud()

func snap() -> void:
	if mode!="play" or paused or phase!="ready": return
	phase="live"
	play_time=0.0
	play_sequence+=1
	last_recap=""
	hud.set_message(current_play.to_upper(),1.0)

func controlled_index() -> int:
	if position_role=="LB": return 16
	if position_role=="WR": return 6
	if position_role=="RB": return 10
	return carrier if carrier>=0 and carrier<11 else 0

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause_game") and mode=="play":
		_set_paused(not paused)
		get_viewport().set_input_as_handled()
		return
	if mode!="play" or paused: return
	if event.is_action_pressed("snap"): snap()
	if event.is_action_pressed("camera_view"): wide_camera=not wide_camera
	if event.is_action_pressed("pass_1"):
		if position_role=="LB": attempt_user_tackle()
		else: _request_pass(0)
	if event.is_action_pressed("pass_2"): _request_pass(1)
	if event.is_action_pressed("pass_3"): _request_pass(2)
	if event.is_action_pressed("cut_left"): start_skill(-1)
	if event.is_action_pressed("cut_right"):
		if position_role=="LB": attempt_user_tackle()
		else: start_skill(1)

func _set_paused(value: bool) -> void:
	if mode!="play": return
	paused=value
	hud.show_pause(paused)

func _request_pass(target: int) -> void:
	if mode!="play" or paused or phase!="live": return
	if position_role=="WR":
		if carrier==0 and not pass_used:
			requested_pass=true
			hud.set_message("CALL RECEIVED · KEEP WORKING YOUR ROUTE",1.0)
			if play_time>=0.9: throw_ball(0)
	elif position_role=="QB": throw_ball(target)

func throw_ball(target: int) -> bool:
	if phase!="live" or carrier!=0 or not flight.is_empty() or pass_used: return false
	if crossed_scrimmage or actors[0].global_position.z>spot:
		crossed_scrimmage=true
		hud.set_message("PAST SCRIMMAGE · RUN ONLY",1.4)
		return false
	target=clampi(target,0,2)
	var receiver=actors[6+target]
	var start: Vector3 = actors[0].global_position+Vector3(0.24,1.35,0.25)
	var duration: float = clampf(start.distance_to(receiver.global_position)/24.0,0.4,1.65)
	var end: Vector3 = receiver.global_position+receiver.velocity*duration*0.94
	end.x=clampf(end.x,-25.8,25.8)
	end.z=clampf(end.z,-8.0,108.0)
	end.y=1.3
	flight={"start":start,"end":end,"duration":duration,"t":0.0,"target":6+target}
	carrier=-1
	pass_used=true
	requested_pass=false
	stats.attempts+=1
	actors[0].play_action("throw")
	return true

func start_skill(side: int=0) -> void:
	if mode!="play" or paused or phase!="live" or stamina<0.18 or skill_cooldown>0.0 or not skill.is_empty(): return
	var index:=controlled_index()
	var right: Vector3 = camera.global_basis.x
	right.y=0.0
	right=right.normalized()
	var nearest: int = -1
	var distance := INF
	for i in range(0 if position_role=="LB" else 11,11 if position_role=="LB" else 22):
		var dist: float = actors[i].global_position.distance_to(actors[index].global_position)
		if dist<distance:
			distance=dist
			nearest=i
	if side==0:
		side=-1 if nearest>=0 and (actors[nearest].global_position-actors[index].global_position).dot(right)>0 else 1
	skill={"index":index,"side":side,"right":right,"t":0.0,"duration":0.38,"distance":1.1+float(attributes.get("speed",65))*0.0055}
	stamina-=0.18
	skill_cooldown=2.4
	if carrier==index and nearest>=11 and distance>1.0 and distance<3.4:
		overcommit[nearest]={"t":0.5,"point":actors[index].global_position+actors[index].velocity*0.35}
		actors[nearest].stumble=0.45
	hud.set_message("LATERAL CUT" if position_role=="LB" else "JUKE LEFT" if side<0 else "JUKE RIGHT",0.7)

func attempt_user_tackle() -> void:
	if position_role!="LB" or phase!="live" or paused or carrier<0 or user_tackle_cooldown>0.0: return
	user_tackle_cooldown=1.0
	if actors[16].global_position.distance_to(actors[carrier].global_position)<1.6:
		begin_tackle(16)
	else:
		actors[16].stumble=0.35
		hud.set_message("MISSED TACKLE · RECOVER",0.8)

func _physics_process(delta: float) -> void:
	if not ready_complete: return
	if paused: return
	for i in range(actors.size()): actors[i].set_ball_carrier(i==carrier)
	if mode=="play":
		match phase:
			"live": _live_step(delta)
			"tackle": _tackle_step(delta)
			"dead": _dead_step(delta)
			"simulation": _simulation_step(delta)
			"ready":
				for actor in actors: actor.drive(Vector3.ZERO,delta)
		_update_hud()
	else:
		for actor in actors: actor.drive(Vector3.ZERO,delta)
	_attach_ball()
	_update_camera(delta)
	for i in range(3):
		pass_markers[i].global_position=actors[6+i].global_position+Vector3(0,2.45,0)
		pass_markers[i].visible=mode=="play" and phase=="live" and carrier==0 and not crossed_scrimmage
	active_ring.global_position=actors[controlled_index()].global_position+Vector3(0,0.04,0)
	active_ring.visible=mode=="play"
	scrimmage.visible=mode=="play"
	first_down_line.visible=mode=="play"

func _live_step(delta: float) -> void:
	game_clock=maxf(0.0,game_clock-delta)
	play_time+=delta
	catch_grace=maxf(0.0,catch_grace-delta)
	skill_cooldown=maxf(0.0,skill_cooldown-delta)
	user_tackle_cooldown=maxf(0.0,user_tackle_cooldown-delta)
	for i in range(22): tackle_cooldowns[i]=maxf(0.0,tackle_cooldowns[i]-delta)
	for i in overcommit.keys():
		overcommit[i].t-=delta
		if overcommit[i].t<=0: overcommit.erase(i)
	if not skill.is_empty():
		skill.t+=delta
		if skill.t>=skill.duration: skill.clear()
	var sprinting: bool = Input.is_action_pressed("sprint") and stamina>0.05
	stamina=clampf(stamina+(-0.19 if sprinting else 0.15)*delta,0.0,1.0)
	var input := Input.get_vector("left","right","forward","backward")
	var forward: Vector3 = -camera.global_basis.z
	forward.y=0
	forward=forward.normalized()
	var right: Vector3 = camera.global_basis.x
	right.y=0
	right=right.normalized()
	var desired: Vector3 = right*input.x-forward*input.y
	var speed: float = clampf((6.1 if sprinting else 5.5)+(float(attributes.get("speed",65))-65.0)*(0.025 if sprinting else 0.02),4.8,6.65)
	desired*=speed
	var controlled:=controlled_index()
	if not skill.is_empty() and int(skill.index)==controlled:
		var u: float = skill.t/skill.duration
		desired+=skill.right*skill.side*skill.distance*6.0*u*(1.0-u)/skill.duration
		desired=desired.limit_length(8.4)
	actors[controlled].drive(desired,delta)
	if carrier==0 and actors[0].global_position.z>spot: crossed_scrimmage=true
	if is_run and carrier==0 and not pass_used and play_time>0.65:
		carrier=10
		pass_used=true
		catch_grace=0.25
		hud.set_message("HANDOFF · FIND YOUR GAP",1.0)
	if controlled!=0:
		if carrier==0 and flight.is_empty(): _pocket_qb(delta)
		else: actors[0].drive(Vector3.ZERO,delta)
	for i in range(1,11):
		if i==controlled: continue
		var actor=actors[i]
		if i==carrier:
			var lane: float = 7.0 if current_play=="Stretch Right" else -4.0 if current_play in ["Power Left","Counter"] else 1.5
			_move_to(actor,Vector3(lane if actor.global_position.z<spot+4.0 else actor.global_position.x,0,actor.global_position.z+10.0),6.0,delta)
		elif i<=5:
			var defender=actors[11+((i-1)%4)]
			var goal: Vector3 = defender.global_position
			goal.z-=1.0
			if not is_run:
				goal.x=clampf(goal.x,actor.home.x-1.7,actor.home.x+1.7)
				goal.z=spot-0.8-minf(1.2,play_time*0.35)
			_move_to(actor,goal,4.8,delta)
		elif is_run:
			var defender=actors[15+(i%3)]
			_move_to(actor,defender.global_position-Vector3(0,0,0.9),5.2,delta)
		else:
			var goal: Vector3 = flight.end if not flight.is_empty() and int(flight.target)==i else _route_goal(i,play_time+0.3)
			_move_to(actor,goal,6.0,delta)
	for i in range(11,22):
		if i==controlled: continue
		_defender_step(i,delta)
	_resolve_blocks(delta)
	if not flight.is_empty(): _flight_step(delta)
	if phase=="live" and carrier>=0 and carrier<11:
		var p: Vector3 = actors[carrier].global_position
		if p.z>=100.0:
			finish_play("TOUCHDOWN")
		elif p.z<=-10.0 or (p.z<0.0 and absf(p.x)>26.67):
			finish_play("SAFETY")
		elif absf(p.x)>26.67:
			finish_play("OUT OF BOUNDS")
		elif play_time>0.8 and catch_grace<=0.0:
			for i in range(11,22):
				if tackle_cooldowns[i]<=0.0 and _flat_distance(actors[i].global_position,p)<0.76:
					begin_tackle(i)
					break
	for i in range(22):
		if i!=carrier:
			actors[i].global_position.x=clampf(actors[i].global_position.x,-27.5,27.5)
			actors[i].global_position.z=clampf(actors[i].global_position.z,-8.0,108.0)

func _move_to(actor: Node3D,goal: Vector3,speed: float,delta: float) -> void:
	var direction: Vector3 = goal-actor.global_position
	direction.y=0
	var desired := Vector3.ZERO
	if direction.length()>0.25: desired=direction.normalized()*minf(speed,direction.length()*3.0)
	actor.drive(desired,delta)

func _route_goal(index: int,t: float) -> Vector3:
	var start: Vector3 = actors[index].home
	var stem: float = minf(7.0,maxf(2.0,(106.0-spot)*0.35))
	var z: float = start.z+minf(t*5.6,stem)
	var x: float = start.x
	var after: float = maxf(0.0,t-stem/5.6)
	var side: float = -1.0 if start.x<0 else 1.0
	match current_play:
		"Slants","Mesh":
			x-=side*after*4.0
			z+=after*3.2
		"Cross":
			x-=side*after*5.5
			z+=after*1.0
		"Out":
			x+=side*after*4.8
			z+=after*0.5
		"Curl":
			z-=minf(1.8,after*1.5)
		"Corner":
			x+=side*after*3.3
			z+=after*4.1
		"Post":
			x-=side*after*2.8
			z+=after*4.8
		"Screen":
			x-=side*minf(6.0,t*3.0)
			z=start.z+minf(2.0,t*1.3)
		_:
			z+=after*5.0
	return Vector3(clampf(x,-24.8,24.8),0,clampf(z,-8.0,107.0-(index%3)*0.65))

func _pocket_qb(delta: float) -> void:
	var goal: Vector3 = actors[0].home-Vector3(0,0,minf(1.5,play_time*1.4))
	var danger:=99.0
	for i in range(11,15): danger=minf(danger,_flat_distance(actors[i].global_position,actors[0].global_position))
	if danger<2.4: goal.x+=1.2 if actors[11].global_position.x<actors[0].global_position.x else -1.2
	_move_to(actors[0],goal,2.5,delta)
	if is_run: return
	if position_role=="WR":
		if requested_pass and play_time>=0.9: throw_ball(0)
		elif play_time>5.5 or (play_time>3.4 and danger<2.0): throw_ball(_best_receiver())
	elif position_role=="LB" and play_time>2.6: throw_ball(_best_receiver())

func _best_receiver() -> int:
	var best:=0
	var value:=-1.0
	for rec in range(3):
		var nearest:=99.0
		for i in range(15,22): nearest=minf(nearest,_flat_distance(actors[6+rec].global_position,actors[i].global_position))
		if nearest>value:
			value=nearest
			best=rec
	return best

func _defender_step(index: int,delta: float) -> void:
	var actor=actors[index]
	var runner=actors[maxi(0,carrier)]
	var goal: Vector3
	var rusher: bool = index<15
	var run_read: bool = (carrier>0 and flight.is_empty()) or (carrier==0 and actors[0].global_position.z>spot+0.6)
	if run_read:
		var dist: float = _flat_distance(actor.global_position,runner.global_position)
		var lead: float = minf(0.24 if index<15 else 0.42 if index<18 else 0.62,dist/16.0)
		goal=runner.global_position+runner.velocity*lead
		var spread: float = clampf((dist-1.3)/7.0,0.0,1.0)
		goal.x+=(signf(actor.global_position.x-runner.global_position.x)*0.45 if index<18 else -signf(runner.global_position.x)*0.7)*spread
	elif rusher:
		goal=actors[0].global_position
	elif not flight.is_empty() and float(flight.t)>0.22 and _flat_distance(actor.global_position,flight.end)<12.0:
		goal=flight.end
	elif index in [18,19]:
		goal=actors[6+index-18].global_position+Vector3(0,0,1.8)
	elif index>=20:
		var target: int = 6 if index==20 else 7
		goal=Vector3(lerpf(actor.home.x,actors[target].global_position.x,0.35),0,maxf(actor.home.z,actors[target].global_position.z+3.0))
	else:
		goal=actor.home+Vector3(clampf(actors[0].global_position.x*0.2,-3,3),0,minf(3.0,play_time*0.5))
	if overcommit.has(index): goal=overcommit[index].point
	goal.x=clampf(goal.x,-26.0,26.0)
	goal.z=clampf(goal.z,-8.0,108.0)
	var speed: float = 5.4 if rusher else 5.75 if index in [18,19] else 6.15
	var reaction: float = 0.2+float((index*7+play_sequence*3)%11)*0.02+(0.14 if index>=18 else 0.0)
	if play_time<reaction: speed=0.0
	if rusher:
		var hold: float = 5.0 if position_role=="WR" else 3.1 if is_run else 3.8
		if play_time<hold:
			for blocker in range(1,6):
				if _flat_distance(actors[blocker].global_position,actor.global_position)<1.35:
					speed*=0.44
					break
	_move_to(actor,goal,speed,delta)

func _resolve_blocks(delta: float) -> void:
	var hold: float = 5.0 if position_role=="WR" else 3.1 if is_run else 3.8
	for blocker in range(1,6):
		if play_time>hold: continue
		for defender in range(11,15):
			var a=actors[blocker]
			var b=actors[defender]
			var distance: float = _flat_distance(a.global_position,b.global_position)
			if distance<1.1:
				var away: Vector3 = b.global_position-a.global_position
				away.y=0
				if away.length()<0.01: away=Vector3.FORWARD
				b.global_position+=away.normalized()*(1.1-distance)*0.45
				if is_run: b.global_position.x+=signf(b.global_position.x-2.0)*delta*0.55

func _flight_step(delta: float) -> void:
	flight.t+=delta
	var t: float = minf(1.0,float(flight.t)/float(flight.duration))
	football.global_position=(flight.start as Vector3).lerp(flight.end,t)
	football.position.y+=sin(t*PI)*maxf(2.5,(flight.start as Vector3).distance_to(flight.end)*0.13)
	football.rotate_x(delta*14.0)
	if t<1.0: return
	var target: int = flight.target
	var point: Vector3 = flight.end
	var rec_distance: float = _flat_distance(actors[target].global_position,point)
	var intercept:=-1
	for i in range(11,22):
		if _flat_distance(actors[i].global_position,point)<1.0: intercept=i
	if intercept>=0 and rec_distance>1.4:
		carrier=intercept
		flight.clear()
		finish_play("INTERCEPTED",false,true)
		return
	var radius: float = 0.65+0.4*pow(float(attributes.get("catching",65))/100.0,1.5) if position_role=="WR" and target==6 else 1.8
	if rec_distance<=radius:
		carrier=target
		stats.completions+=1
		if target==controlled_index(): stats.catches+=1
		actors[target].play_action("catch")
		catch_grace=0.32
		flight.clear()
		hud.set_message("CAUGHT · TURN UPFIELD",1.1)
	else:
		flight.clear()
		finish_play("INCOMPLETE",true)

func begin_tackle(defender: int,force_down: bool=false) -> bool:
	if phase!="live" or carrier<0 or carrier>=11 or defender<11 or defender>=22: return false
	if tackle_cooldowns[defender]>0: return false
	var runner=actors[carrier]
	var other=actors[defender]
	var direction: Vector3 = runner.velocity
	direction.y=0
	var moving: bool = direction.length()>2.5
	if direction.length()<0.2: direction=runner.global_position-other.global_position
	if direction.length()<0.01: direction=Vector3(0,0,1)
	direction=direction.normalized()
	var toward: Vector3 = other.global_position-runner.global_position
	toward.y=0
	var square: float = toward.normalized().dot(direction)
	if not force_down and moving and square<0.4 and rng.randf()<0.27:
		other.stumble=0.8
		runner.stumble=0.35
		tackle_cooldowns[defender]=1.1
		catch_grace=0.3
		hud.set_message("BROKEN TACKLE · KEEP RUNNING",1.0)
		return false
	tackle={"runner":carrier,"defender":defender,"t":0.0,"duration":1.25,"spot":runner.global_position.z,"start":runner.global_position,"direction":direction}
	phase="tackle"
	skill.clear()
	for actor in actors: actor.velocity=Vector3.ZERO
	runner.play_action("tackle")
	other.play_action("tackle")
	if position_role=="LB" and defender==16: stats.tackles+=1
	hud.set_message("WRAP & DRIVE",1.0)
	return true

func _tackle_step(delta: float) -> void:
	for actor in actors: actor.drive(Vector3.ZERO,delta)
	game_clock=maxf(0.0,game_clock-delta)
	tackle.t+=delta
	var t: float = minf(1.0,float(tackle.t)/float(tackle.duration))
	var runner=actors[int(tackle.runner)]
	var defender=actors[int(tackle.defender)]
	var travel: float = smoothstep(0.12,0.7,t)*0.55
	runner.global_position=(tackle.start as Vector3)+tackle.direction*travel
	defender.global_position=runner.global_position-tackle.direction*0.5+Vector3(0.25,0,0)
	if t>=1.0:
		runner.set_down()
		defender.set_down()
		phase="live"
		finish_play("TACKLED",false,false,float(tackle.spot))

func finish_play(reason: String,incomplete: bool=false,turnover: bool=false,contact_spot: float=NAN) -> void:
	if phase!="live": return
	var dead_spot: float = contact_spot if not is_nan(contact_spot) else actors[carrier].global_position.z if carrier>=0 else spot
	var gain: float = 0.0 if incomplete else dead_spot-snap_spot
	var ended:=turnover
	if position_role!="LB": stats.yards+=gain
	if turnover:
		spot=25.0
		down=1
		line_to_gain=35.0
	elif not incomplete and dead_spot>=100.0:
		if position_role=="LB": away_score+=7
		else:
			home_score+=7
			stats.td+=1
		reason="TOUCHDOWN"
		ended=true
	elif not incomplete and dead_spot<=0.0:
		if position_role=="LB": home_score+=2
		else: away_score+=2
		reason="SAFETY"
		ended=true
	else:
		if not incomplete: spot=clampf(dead_spot,0,100)
		if spot>=line_to_gain:
			down=1
			line_to_gain=minf(100.0,spot+10.0)
			if reason=="TACKLED": reason="FIRST DOWN"
		else:
			down+=1
			if down>4:
				reason="TURNOVER ON DOWNS"
				ended=true
	if gain>=20.0: stats.big_plays+=1
	last_recap=reason+" · "+("+" if gain>=0 else "")+str(roundi(gain))+" YDS"
	phase="dead"
	dead_timer=3.0 if reason=="TOUCHDOWN" else 2.2
	runoff=0.0 if ended or incomplete or reason=="OUT OF BOUNDS" else 6.0
	pending_possession=ended
	flight.clear()
	skill.clear()
	for actor in actors:
		actor.velocity=Vector3.ZERO
		actor.speed=0.0
	hud.set_message(reason+(" · EXPLOSIVE PLAY" if gain>=20.0 and reason!="TOUCHDOWN" else ""),2.5)
	_update_hud()

func _dead_step(delta: float) -> void:
	var run: float = minf(runoff,minf(game_clock,delta*2.5))
	runoff-=run
	game_clock-=run
	dead_timer-=delta
	if dead_timer>0: return
	if game_clock<=0:
		_end_game()
	elif pending_possession:
		_start_simulation()
	else:
		formation()

func _start_simulation() -> void:
	pending_possession=false
	var seconds: float = rng.randf_range(18,40)
	var roll: float = rng.randf()
	var points: int = 7 if roll<0.36 else 3 if roll<0.58 else 0
	var outcome: String = "TOUCHDOWN" if points==7 else "FIELD GOAL" if points==3 else "PUNT" if roll<0.85 else "TURNOVER"
	simulation={"t":0.0,"duration":4.2,"seconds":minf(seconds,game_clock),"clock":game_clock,"points":points if game_clock>=seconds else 0,"outcome":outcome if game_clock>=seconds else "CLOCK EXPIRES"}
	phase="simulation"
	hud.set_message((home_team if position_role=="LB" else away_team)+" HAS POSSESSION",2.0)

func _simulation_step(delta: float) -> void:
	simulation.t+=delta
	var t: float = minf(1.0,float(simulation.t)/float(simulation.duration))
	game_clock=maxf(0.0,float(simulation.clock)-float(simulation.seconds)*t)
	if t>=1.0:
		if position_role=="LB": home_score+=int(simulation.points)
		else: away_score+=int(simulation.points)
		hud.set_message(str(simulation.outcome)+" · "+str(roundi(simulation.seconds))+"s ELAPSED",2.0)
		spot=25.0
		down=1
		line_to_gain=35.0
		phase="dead"
		dead_timer=2.0
		runoff=0
		simulation.clear()

func _end_game() -> void:
	mode="result"
	if career_active:
		var result: Dictionary = stats.duplicate(true)
		result.home=home_score
		result.away=away_score
		Career.complete_game(career,result)
		Career.save(career)
	var body: String = "%s %d – %d %s\n%d yards · %d TD · %d/%d passing · %d tackles\n" % [home_team,home_score,away_score,away_team,roundi(stats.yards),stats.td,stats.completions,stats.attempts,stats.tackles]
	if career_active:
		body+="Return to your coach for upgrades, recruiting and your next game."
	else:
		body+="Create a career to turn your performance into scholarship offers."
	hud.show_result("FINAL WHISTLE",body)

func _attach_ball() -> void:
	if not flight.is_empty(): return
	if carrier>=0 and carrier<actors.size():
		football.global_position=actors[carrier].ball_anchor()
		football.rotation=Vector3(0.3,actors[carrier].rotation.y,0.15)

func _update_camera(delta: float,immediate: bool=false) -> void:
	var target: Vector3
	var eye: Vector3
	if "--athlete-preview" in OS.get_cmdline_user_args():
		var focus: Vector3 = actors[0].global_position
		target=focus+Vector3(0,1.1,0)
		eye=focus+Vector3(2.2,1.45,3.2)
	elif mode in ["home","career","result"]:
		target=Vector3(0,2,50)
		eye=Vector3(43,27,4)
	else:
		var focus: Vector3 = actors[controlled_index()].global_position
		var sign_z: float = -1.0 if position_role=="LB" else 1.0
		eye=focus+Vector3(14.0 if wide_camera else 0.0,20.0 if wide_camera else 9.0,-sign_z*(27.0 if wide_camera else 17.5))
		target=focus+Vector3(0,1.0,sign_z*9.0)
	if immediate: camera.global_position=eye
	else: camera.global_position=camera.global_position.lerp(eye,1.0-exp(-delta*4.5))
	camera.look_at(target,Vector3.UP)

func _update_hud() -> void:
	if hud==null: return
	var can_pass: bool = phase=="live" and carrier==0 and not pass_used and not crossed_scrimmage and actors[0].global_position.z<=spot
	var info: Dictionary = {"home":home_score,"away":away_score,"home_team":home_team,"away_team":away_team,"time":game_clock,"down":down,"distance":maxf(0,line_to_gain-spot),"spot":spot,"position":position_role,"phase":"RUN ONLY" if phase=="live" and crossed_scrimmage and carrier==0 else phase.to_upper(),"stamina":stamina,"can_pass":can_pass,"crossed_scrimmage":crossed_scrimmage,"has_ball":carrier==0,"stats":"%d YDS · %d TD · %d/%d PASS · %d TKL" % [roundi(stats.get("yards",0)),stats.get("td",0),stats.get("completions",0),stats.get("attempts",0),stats.get("tackles",0)],"play":current_play,"challenge":last_recap}
	hud.update_match(info)
	if stadium!=null: stadium.update_score(home_score,away_score,roundi(game_clock))

func _flat_distance(a: Vector3,b: Vector3) -> float:
	return Vector2(a.x-b.x,a.z-b.z).length()

func snapshot() -> Dictionary:
	return {"mode":mode,"phase":phase,"players":actors.size(),"role":position_role,"carrier":carrier,"can_pass":phase=="live" and carrier==0 and not crossed_scrimmage and not pass_used and actors[0].global_position.z<=spot,"crossed":crossed_scrimmage,"flight":not flight.is_empty(),"attempts":stats.get("attempts",0),"home":home_score,"away":away_score,"spot":spot,"down":down,"clock":game_clock,"stamina":stamina,"skill":not skill.is_empty(),"career":career.duplicate(true)}

func _capture_screenshot() -> void:
	await RenderingServer.frame_post_draw
	var image := get_viewport().get_texture().get_image()
	if image!=null:
		var path: String = OS.get_environment("FOOTBALL_SCREENSHOT")
		if path.is_empty(): path="user://native-preview.png"
		image.save_png(path)
		print("Native screenshot saved: "+path)
	if "--quit-after-screenshot" in OS.get_cmdline_user_args(): get_tree().quit()
