# Building native desktop files

Use Godot 4.6.3 stable. No proprietary engine or paid asset downloads are required.

From the repository root:

```sh
python3 native/tools/package.py --platform all --data-home /workspace/native-tools
```

Use any writable path for `--data-home` on another development computer. The
script sets Godot's XDG data/cache/config folders for the export process only.
The source archive can be rebuilt with:

```sh
python3 native/tools/package.py --platform source
```

The desktop ZIPs contain a release executable, its `.pck`, instructions and
license notices. Keep the executable and pack together after extracting.
Windows users do not need the Godot editor installed to play the release ZIP.

The export templates come from Godot's official GitHub 4.6.3 stable release.
`fetch_export_templates.py` requests ZIP byte ranges so unrelated Android,
macOS and other platform templates are not downloaded. Python's ZIP reader
verifies each extracted member's CRC; the script records the official source
URL, sizes and SHA-256 of the exact extracted binaries. It does not claim to
verify a digest for the entire 1.25 GB archive, since most bytes were not fetched.

`downloads/build-manifest.json` and `SHA256SUMS.txt` record the resulting ZIPs.
Windows cross-export can succeed on Linux. That does not mean a Windows runtime
test took place; report native Linux tests and Windows runtime tests separately.

The original artwork is documented in `assets/asset-notes.md`. The Godot MIT
license and its bundled third-party notices are included with the releases.
