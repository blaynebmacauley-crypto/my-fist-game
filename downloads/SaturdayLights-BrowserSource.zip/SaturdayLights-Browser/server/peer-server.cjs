'use strict';
// Local development signaling only. Public browser rooms use the configured
// PeerJS broker; all football inputs/snapshots travel on the WebRTC data channel.
const {PeerServer}=require('peer');
const port=Number(process.env.PORT||8092);
if(!Number.isInteger(port)||port<1024||port>65535)throw new Error('PORT must be an unprivileged TCP port');
const server=PeerServer({
  host:process.env.HOST||'0.0.0.0',port,path:'/signal',key:'peerjs',
  allow_discovery:false,concurrent_limit:32,expire_timeout:10000,alive_timeout:60000,
  corsOptions:{origin:[/^http:\/\/127\.0\.0\.1:\d+$/, /^http:\/\/localhost:\d+$/],methods:['GET','POST'],optionsSuccessStatus:204},
});
server.get('/health',(_request,response)=>response.json({ok:true,service:'saturday-lights-dev-signaling'}));
server.on('error',error=>{console.error('Signaling server error:',error.message);process.exitCode=1;});
console.log(`Development PeerJS broker listening on http://0.0.0.0:${port}/signal`);
