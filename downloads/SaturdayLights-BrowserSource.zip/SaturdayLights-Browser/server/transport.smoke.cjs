'use strict';
// Two isolated browser contexts exchange data over actual RTCPeerConnections.
// The local broker only relays signaling and never football snapshots.
let playwright;try{playwright=require('playwright');}catch{playwright=require('../browser/node_modules/playwright');}
const {chromium}=playwright;
const assert=require('node:assert/strict');
const ORIGIN=process.env.GAME_URL||'http://127.0.0.1:8091';
const PEER_PORT=Number(process.env.PEER_PORT||8092);
const options={host:'127.0.0.1',port:PEER_PORT,path:'/signal',secure:false,config:process.env.TEST_TURN_URL?{iceTransportPolicy:'relay',iceServers:[{urls:process.env.TEST_TURN_URL,username:process.env.TEST_TURN_USER||'localqa',credential:process.env.TEST_TURN_PASSWORD||'localqatest'}]}:{iceServers:[]}};

(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-features=WebRtcHideLocalIpsWithMdns']});
 const errors=[];
 async function endpoint(){
  const context=await browser.newContext();const page=await context.newPage();page.setDefaultTimeout(20000);page.on('pageerror',error=>errors.push(error.message));await page.goto(ORIGIN+'/vendor/THREE-LICENSE.txt');
  await page.evaluate(async peerOptions=>{
   const {createMultiplayerTransport}=await import('./../multiplayer-transport.js');
   window.messages=[];window.peerEvents=0;window.closeEvents=[];window.statusEvents=[];
   window.transport=createMultiplayerTransport({peerOptions,onMessage:message=>messages.push(message),onPeer:()=>peerEvents++,onClose:reason=>closeEvents.push(String(reason?.message||reason||'')),onStatus:(state,message)=>statusEvents.push({state:typeof state==='string'?state:String(state?.status||''),message:String(message||state?.message||'')})});
  },options);
  return {page,context};
 }
 async function connected(page,value=true){await page.waitForFunction(value=>transport.getstate().connected===value,value,{polling:50,timeout:15000});}
 async function received(page,type){await page.waitForFunction(type=>messages.some(message=>message.type===type),type,{polling:50,timeout:10000});}
 try{
  const host=await endpoint(),guest=await endpoint(),third=await endpoint();
  await host.page.bringToFront();
  const room=await host.page.evaluate(()=>transport.createRoom());assert.ok(room&&typeof room.code==='string'&&room.code.length>=8);assert.ok(!transportHasCredential(room),'room invitation contains no credentials');
  await guest.page.bringToFront();await guest.page.evaluate(code=>transport.joinRoom(code),room.code);await connected(host.page);await connected(guest.page);
  assert.equal(await host.page.evaluate(()=>peerEvents),1);assert.equal(await guest.page.evaluate(()=>peerEvents),1);
  assert.equal(await guest.page.evaluate(()=>transport.send({type:'input',seq:1,x:.5,z:-.5,sprint:true})),true);await received(host.page,'input');
  assert.equal(await host.page.evaluate(()=>transport.send({type:'snapshot',seq:1,score:{host:7,guest:0},actors:[{x:1,z:25}]})),true);await received(guest.page,'snapshot');
  const input=await host.page.evaluate(()=>messages.find(message=>message.type==='input'));assert.deepEqual(input,{type:'input',seq:1,x:.5,z:-.5,sprint:true});
  const snapshot=await guest.page.evaluate(()=>messages.find(message=>message.type==='snapshot'));assert.equal(snapshot.score.host,7);assert.equal(snapshot.actors[0].z,25);
  console.log('PASS real WebRTC: isolated host/guest browser contexts exchange football inputs and authoritative snapshots');

  const bad=await guest.page.evaluate(()=>{const cycle={};cycle.self=cycle;return [transport.send(null),transport.send([]),transport.send(cycle),transport.send({type:'large',payload:'x'.repeat(70000)})];});assert.deepEqual(bad,[false,false,false,false]);
  assert.equal(await host.page.evaluate(()=>transport.getstate().connected),true,'invalid local send does not kill the match');
  console.log('PASS transport rejects non-object, cyclic and oversized messages without disconnecting the accepted pair');

  const full=await third.page.evaluate(async code=>{try{await transport.joinRoom(code);return {joined:true,state:transport.getstate()};}catch(error){return {joined:false,message:error.message,state:transport.getstate()};}},room.code);
  if(full.joined)await connected(third.page,false);
  assert.equal(await third.page.evaluate(()=>transport.getstate().connected),false,'third player is not admitted');
  assert.equal(await host.page.evaluate(()=>transport.getstate().connected),true);assert.equal(await guest.page.evaluate(()=>transport.getstate().connected),true);
  assert.equal(await host.page.evaluate(()=>transport.send({type:'after-full',seq:2})),true);await received(guest.page,'after-full');
  console.log('PASS two-player room stays full and a third join cannot replace the accepted guest');

  await host.page.bringToFront();await host.page.evaluate(()=>{transport.close();transport.close();});await connected(host.page,false);await connected(guest.page,false);
  assert.equal(await guest.page.evaluate(()=>transport.send({type:'after-close'})),false);
  const next=await host.page.evaluate(()=>transport.createRoom());assert.notEqual(next.code,room.code,'new room gets a fresh private identifier');
  await third.page.evaluate(()=>transport.close());await third.page.evaluate(code=>transport.joinRoom(code),next.code);await connected(host.page);await connected(third.page);
  await third.page.evaluate(()=>transport.send({type:'recreated',seq:1}));await received(host.page,'recreated');
  console.log('PASS disconnect handling, idempotent close and fresh-room recreation');

  await third.page.evaluate(()=>transport.close());const invalid=await third.page.evaluate(async()=>{try{await transport.joinRoom('bad!');return false;}catch{return true;}});assert.equal(invalid,true,'invalid room codes fail before matchmaking');
  assert.deepEqual(errors,[]);console.log('PASS local PeerJS transport smoke; no browser runtime errors');
 }finally{await browser.close();}
 function transportHasCredential(room){return Object.keys(room).some(key=>/password|credential|turn/i.test(key));}
})().catch(error=>{console.error(error);process.exit(1)});
