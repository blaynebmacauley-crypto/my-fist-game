# Local multiplayer verification

This development-only PeerJS signaling server is not deployed on GitHub Pages. Run `npm install` here, then `npm start` (port 8092, path `/signal`; override PORT/HOST). Serve ../browser on port 8091 separately.

Run `npm test` here for the real two-context transport checks. Run `npm run test:multiplayer --prefix ../browser` for the complete shared-game integration suite. Override GAME_URL, PEER_PORT or CHROMIUM_PATH as needed. Playwright is a developer tool, not a player download.

By default local tests use direct host ICE candidates and no external ICE services. If managed browser policy requires relayed WebRTC, run a local TURN server with TCP support and set TEST_TURN_URL, TEST_TURN_USER and TEST_TURN_PASSWORD on both test commands. For example, TEST_TURN_URL=turn:127.0.0.1:3479?transport=tcp, with credentials matching the local relay configuration. Tests then require relay candidates. Keep managed browser policies intact.

These checks prove real local browser-to-browser delivery. They do not establish public broker or Internet NAT traversal availability. Production uses the public PeerJS broker and public STUN/TURN services; a local development relay is not production hosting.
