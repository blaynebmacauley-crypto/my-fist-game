#!/usr/bin/env python3
"""Publish a reviewed browser snapshot while preserving the native release archive."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[1]
BROWSER=ROOT/"browser" if (ROOT/"browser").is_dir() else ROOT
EXCLUDED={"downloads","node_modules",".git","__pycache__",".godot","playwright-report","test-results"}

def git(*args,env=None):
    return subprocess.check_output(["git",*args],cwd=ROOT,env=env,text=True).strip()

def browser_files():
    return sorted(p for p in BROWSER.rglob("*") if p.is_file() and not any(part in EXCLUDED for part in p.relative_to(BROWSER).parts))

def source_archive(files):
    output=ROOT/"downloads"/"SaturdayLights-BrowserSource.zip"
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,"w",zipfile.ZIP_DEFLATED,compresslevel=8) as archive:
        for path in files:
            archive.write(path,"SaturdayLights-Browser/"+path.relative_to(BROWSER).as_posix())
        archive.write(Path(__file__),"SaturdayLights-Browser/tools/publish_browser.py")
    return output

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--message",default="Restore browser play with imported athletes, stadium graphics and broadcast layouts")
    parser.add_argument("--prepare-only",action="store_true")
    args=parser.parse_args()
    files=browser_files()
    archive=source_archive(files)
    print(f"Prepared {len(files)} browser files and {archive.name} ({archive.stat().st_size} bytes)",flush=True)
    if args.prepare_only:return
    parent=git("ls-remote","origin","refs/heads/gh-pages").split()[0]
    try:git("cat-file","-e",parent+"^{commit}")
    except subprocess.CalledProcessError:git("fetch","origin","gh-pages")
    with tempfile.TemporaryDirectory(prefix="saturday-publish-") as directory:
        environment=os.environ.copy();environment["GIT_INDEX_FILE"]=str(Path(directory)/"index")
        git("read-tree","--empty",env=environment)
        entries=[(p,p.relative_to(BROWSER).as_posix()) for p in files]
        entries.extend((p,"downloads/"+p.name) for p in sorted((ROOT/"downloads").iterdir()) if p.is_file() and p.suffix in {".zip",".png",".html",".json",".md",".txt"})
        for path,name in entries:
            sha=git("hash-object","-w",str(path));git("update-index","--add","--cacheinfo","100644",sha,name,env=environment)
        marker=Path(directory)/".nojekyll";marker.touch();sha=git("hash-object","-w",str(marker));git("update-index","--add","--cacheinfo","100644",sha,".nojekyll",env=environment)
        tree=git("write-tree",env=environment)
        commit=git("-c","user.name=Codex","-c","user.email=codex@users.noreply.github.com","commit-tree",tree,"-p",parent,"-m",args.message)
        subprocess.run(["git","push","origin",commit+":refs/heads/gh-pages"],cwd=ROOT,check=True)
        print("Published browser snapshot:",commit,flush=True)

if __name__=="__main__":main()
