SATURDAY LIGHTS — NATIVE FOOTBALL PROTOTYPE

PLAY
Extract this whole ZIP into a folder first, then launch SaturdayLights.x86_64.
Keep the game executable and SaturdayLights.pck together.
This build does not require Godot or a browser to be installed.

CONTROLS
WASD / left stick: move the created athlete
Shift / gamepad right trigger: sprint
Space / gamepad A: snap
1, 2, 3: choose a pass target (QB)
1: call for the ball (WR)
Q/E: cut or juke; LB uses E for tackling
Esc: pause
Mouse: menus and on-screen controls

The game includes simplified 11-on-11 football and a condensed career.
Players, coaches and uniforms are fictional. College names identify programs;
there are no licensed player rosters, likenesses or official team logos.
The artwork and animations are original prototype assets, not scanned players.

Your native career is saved locally by Godot in its user data folder.
Browser saves remain in your browser and are not automatically imported.

BUILD / TEST STATUS
Engine: Godot 4.6.3 stable, compatibility renderer.
The Windows x86-64 release is exported on Linux using official Godot templates.
See the accompanying download page or project verification notes for tests run.
No Windows code-signing certificate is included.

LICENSES
Godot Engine is MIT-licensed. Full engine and third-party notices are included
in the licenses folder. See asset-notes.md for original asset provenance.
